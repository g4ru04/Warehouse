﻿

$("#safty").click(function(){
	push_setting_1();
});

function push_setting_1(){ //1
	if($(".push_conversation_list").length==0){
		$(".cs_manager_dialog").after(`
		<div class='push_conversation_list'>
			<div class='push_header bentable'>
				<div class='back bentable-td left'>
					<img alt="" class="my-btn" onclick="push_back1();" src="/images/white-back.png">
				</div>
				<div class='title bentable-td'>選擇推播對象</div>
				<div class='next bentable-td right my-btn' onclick='push_setting_1_2()'><div>下一步</div></div>
			</div>
			<div class='push_conv_search'>
				<img alt="" class="search" src="/images/search.png">
				<input id='filter_name' class="filter_list" oninput="push_refresh_list()" type="text" placeholder="搜尋用戶/車型/車牌" maxlength="10">
			</div>
			<div class='push_conv_checkbox_list bentable'>
				<div class='bentable-td right'>
					<label class="container">近兩周生日
						<input type="checkbox" id='filter_birth' onchange="push_refresh_list()">
						<span class="checkmark"></span>
					</label>
				</div>
				<div class='bentable-td right'>
					<label class="container">即將過保
						<input type="checkbox" id='filter_fen' onchange="push_refresh_list()">
						<span class="checkmark"></span>
					</label>
				</div>
				<div class='bentable-td right'>
					<label class="container">列表全選
						<input type="checkbox" id='select_all' onchange="push_refresh_list()">
						<span class="checkmark"></span>
					</label>
				</div>
			</div>
			<div class="cs_manager_list_container"></div>
		</div>
		`);
		push_refresh_list()
		//$(".push_conversation_list").onchange();
	}else{
		$(".push_conversation_list").show();
	}
	
}

function push_back1(){
	$('.push_conversation_list').hide();
	$('.list_element >div> input:checked').prop("checked", "");
	$('.bentable-td > .container > input:checked').trigger('click')
}
function push_back2(){
	$('.push_edit_message').hide();
	clean_msg();
}
function push_for_someone(id){
	push_setting_2();
	$(".push_edit_message").attr("push_custid_list",id);
	$("#push_amount").html("送出(共1人)");
}

function push_setting_1_2 (){
	if($(".push_conversation_list .cs_manager_list_container input[type='checkbox']:checked").length==0){
		warningMsg("提醒","請選擇推播對象");
		return ;
	}
	
	let push_custid_list =[];
	$(".push_conversation_list .cs_manager_list_container :checked").each(function(){
		push_custid_list.push($(this).attr("customer_id"));
	});

	push_setting_2();
	$(".push_edit_message").attr("push_custid_list",push_custid_list.join(","));
	$("#push_amount").html("送出(共"+push_custid_list.length+"人)")
	
}

function push_setting_2(){
	
	if($(".push_edit_message").length==0){
		let selector 
		if($(".push_conversation_list").length>0){
			selector = $(".push_conversation_list");
		}else{
			selector = $(".cs_manager_dialog");
		}
		selector.after(`
		<div class='push_edit_message'>
			<div class='push_header bentable'>
				<div class='back bentable-td left'>
					<img alt="" class="my-btn" onclick="push_back2()" src="/images/white-back.png">
				</div>
				<div class='title bentable-td'>編輯訊息</div>
				<div class='next bentable-td right my-btn' style='padding-right: 10px;font-size: 19px;' onclick='push_send_message()'><div id='push_amount' style='margin-right:0px'></div></div>
			</div>
			<div class='' style='text-align:center;background-color:#d8e9ff;padding:5px;height: 20px;'>
				<div class='' style=''>預覽畫面</div>
			</div>
			<div class='console' style='background-color: #f4f4f4;height:calc( 100vh - 90px )'>
				<div class='' style='float:right;width:50%;margin-right:5%;'>
					<div id='display_image' style='border:1px solid #999;padding:1px 10px;border-radius:8px;'>
						<div style='text-align:center;margin:30px;'>圖片</div>
					</div>
				</div>
				<div class='' style='float:right;width:60%;margin-right:5%;margin-top:20px;'>
					<div id='display_text' style='border:1px solid #999;padding:4px 20px;border-radius:12px;min-height:20px;border-top-right-radius:0px;background-color:#d8e9ff;word-break:break-all;'>
						<div style='text-align:center;margin:10px;'>文字</div>
					</div>
				</div>
			</div>
			<div class='control-bar' style='position:fixed;bottom:0px;padding:5px;right:0px;left: 0px;background-color:#1b559f;'>
			<input type='file' id='push_picture' name='push_picture' style='display:none;' accept="image/*">
				<div class='box'>
					<div class="box-btn" id="btn-photo" onclick='$("#push_picture").trigger("click");'>
						<div class="btn-photo"></div>
						<div class="box-btn-name">傳送照片</div>
					</div>
					<div class="box-btn" id="btn-talk-tricks" onclick='normal_tricks("#push_message_input");'>
						<div class="btn-talk-tricks"></div>
						<div class="box-btn-name">常用話術</div>
					</div>
				</div>
				<div>
					<textarea id='push_message_input' style='' placeholder=""></textarea>
				</div>
			</div>
			
		</div>
		`);
		$('.push_edit_message textarea').on('change paste keyup', function(e){
			this.style.height = "";this.style.height = this.scrollHeight + "px";
			$("#display_text").html(
				$("<div/>").html($('.push_edit_message textarea').val()).text()
			);
			$(".push_edit_message").attr("push_text",$('.push_edit_message textarea').val());
		})
		$('.push_edit_message #push_picture').on('change',function(e){
			push_pre_upload(this,function(picurl){
				$("#display_image").html(
					"<img style='width:100%;' src='"+picurl+"'>"
				)
				$(".push_edit_message").attr("push_image",picurl);
			});
		})
	}else{
		$(".push_edit_message").show();
	}
}


function push_refresh_list (){
	let gs_conversation_list = Object.values(Connection.conversation_list);
	
	let conv_html = gs_conversation_list;
		
	if($("#filter_name").val().length>0){
		conv_html = conv_html.filter(function(item){
			return (item.detail.CARNM+" | "+item.detail.LICSNO).includes($("#filter_name").val())
					|| item.customer_nickname.includes($("#filter_name").val());
		});
		
		
	}
	if($("#filter_birth").prop("checked")){
		conv_html = conv_html.filter(function(item){
			return item.birth_need_notify=="Y" &&
					item.birth_notify == "Y" &&
					DateDiff(item.detail.BRTHDT) < 15;
		});
	}
	if($("#filter_fen").prop("checked")){
		conv_html = conv_html.filter(function(item){
			return item.fend_need_notify=="Y" &&
					item.fend_notify == "Y" &&
					DateDiff(item.detail.FENDAT) < 15;
		});
	}
	conv_html = conv_html.sort(function(a,b){
		if(a.last_talk_time > b.last_talk_time){
			return -1;
		}else if(a.last_talk_time < b.last_talk_time){
			return 1;
		}else{
			return 0;
		}
	});
	
	conv_html = conv_html.map(function(item){
		// console.log(item);
		let img_str = "";
		if(item.birth_notify=="Y" && DateDiff(item.detail.BRTHDT) < 15){
			img_str+="<img src='/images/cake.png' style='height:20px'/>";
		}
		if(item.fend_notify=="Y" && DateDiff(item.detail.FENDAT) < 15){
			img_str+="<img src='/images/insurance.png' style='height:20px'/>";
		}
		
		return '<div class="list_element" customer_id="'+item.customer_id+'">'+
			  '<div class="img" alt=""><img src="'+item.detail.PICURL+'" alt=""></div>'+
			  '<div class="chat_body">'+
				 '<div class="title">'+item.detail.CARNM+" | "+item.detail.LICSNO+
					 img_str+
				 '</div>'+
				 '<div class="name" customer_id="'+item.customer_id+'">'+item.customer_nickname+'</div>'+
			  '</div>'+
			  '<div class="right_checkbox">'+
				'<input type="checkbox" customer_id="'+item.customer_id+'" '+($("#select_all").prop("checked")?"checked":"")+'>'+
			  '</div>'+
		   '</div>';
		
	});
	// console.log(conv_html);
	$(".push_conversation_list .cs_manager_list_container").html(conv_html);
	
}

function push_send_message(){//3
	
	let custid_list = $(".push_edit_message").attr("push_custid_list").split(",");
	let push_image = $(".push_edit_message").attr("push_image");
	let push_text = $(".push_edit_message").attr("push_text");
	var msg = [];
	if(push_image) msg.push({type: "image",	url: push_image });
	if(push_text) msg.push({type: "text", text: push_text });

	if(push_text==null || push_text.length==0){
		warningMsg("提醒","請填寫推播內容");
		return;
	}
	
	custid_list.forEach(function(element){
	
		let message_obj = {
			type: "service",
			from: {
				id: Connection.service_id,
				name: Connection.service_info.name,
				avatar: "https://customer-service-xiang.herokuapp.com/images/Lexus_icon.png",
			},
			to: {
				id: element,
				//name: Connection.client_info.name,
				avatar: "/images/avatar.png"
			},
			time: Date.now(),
			message: msg
		};
		// image_obj = {
		// 	type: "service",
		// 	from: {
		// 		id: Connection.service_id,
		// 		avatar: "https://customer-service-xiang.herokuapp.com/images/Lexus_icon.png",
		// 	},
		// 	to: {
		// 		id: element,
		// 		avatar: "/images/avatar.png"
		// 	},
		// 	time: Date.now(),
		// 	message: {
		// 		type: "image",
		// 		url: push_image
		// 	}
		// };
		
		// if(push_image) Connection.group_send(image_obj); 
		if(push_text) Connection.group_send(message_obj);
		console.log(message_obj);
	});
	
	$('.list_element > div > input:checked').prop("checked", "");
	$('.bentable-td > .container > input:checked').trigger('click');
	$(".push_edit_message").hide();
	$(".push_conversation_list").hide();
}

function clean_msg(){
	$('#display_image').html('<div style="text-align:center;margin:30px;">圖片</div>');
	$('#display_text').html('<div style="text-align:center;margin:10px;">文字</div>');
	$('#push_message_input').val('')
}

function push_pre_upload(obj,func){
	var tt = 500; //壓縮後最大寬度
	let file_val = $('#push_picture').val();
	let validExts = [".png",".jpg",".jpeg",".gif",".bmp"];
	let file_ext = file_val.substring(file_val.lastIndexOf('.'))
	if (validExts.indexOf(file_ext.toLowerCase()) < 0) {
		$('#push_picture').val('');
		warningMsg("錯誤!","只接受此類圖片檔案：" + validExts.join(", "));
		return ;
	}
	var _this = $(obj)[0], _file = _this.files[0], fileType = _file.type;
	

	var fileReader = new FileReader();
	fileReader.readAsDataURL(_file);
	fileReader.onload = function (event) {
		var result = event.target.result;   //返回的dataURL
		var image = new Image();
		image.src = result;
		image.onload = function () {  //创建一个image对象，给canvas绘制使用
			var cvs = document.createElement('canvas');
			var ctx = cvs.getContext('2d');
			var scale = 1;
			
			if (this.width > tt || this.height > tt) {
				if (this.width > this.height) {
					scale = tt / this.width;
				} else {
					scale = tt / this.height;
				}
			}

			EXIF.getData(image, function(){
				EXIF.getAllTags(this);
				var orientation = EXIF.getTag(this, 'Orientation');       
				switch(orientation){
					case 1:
						//0°
						cvs.height = image.height * scale;
						cvs.width = image.width * scale;
						ctx.drawImage(image, 0, 0, cvs.width, cvs.height);
						break;
					case 6:
						//+90°
						cvs.width = image.height * scale;
						cvs.height = image.width * scale;
						ctx.rotate(90 * Math.PI / 180);
						ctx.drawImage(image, 0, -cvs.width, cvs.height, cvs.width);
						break;
					case 8:
						//-90°
						cvs.width = image.height * scale;
						cvs.height = image.width * scale;
						ctx.rotate(-90 * Math.PI / 180);
						ctx.drawImage(image, -cvs.width, 0, cvs.height, cvs.width);
						break;
					case 3:
						//180°
						cvs.height = image.height * scale;
						cvs.width = image.width * scale;
						ctx.rotate(Math.PI);
						ctx.drawImage(image, -cvs.width, -cvs.height, cvs.width, cvs.height);
						break;
					default:
						cvs.height = image.height * scale;
						cvs.width = image.width * scale;
						ctx.drawImage(image, 0, 0, cvs.width, cvs.height);
				};    
   
			})

			//计算等比缩小后图片宽高
			// cvs.width = this.width * scale;
			// cvs.height = this.height * scale;     
			// ctx.drawImage(this, 0, 0, cvs.width, cvs.height);
			var newImageData = cvs.toDataURL(fileType);   //重新生成图片，fileType为用户选择的图片类型
			var blob = dataURItoBlob(newImageData);
			var data = new FormData();
			data.append("canvasImage", blob);

			$.ajax({
				url: '/upload',
				type: 'POST',
				data: data,
				cache: false,
			    contentType: false,
			    processData: false,
			    method: 'POST',
				success: function(data){
					if(data.status=="success"){
						func(data.url);
					}else{
						warningMsg("錯誤!","檔案上傳失敗");
					}
				},
				error: function(xhr, status, error) {
					console.log(xhr);
					console.log(status);
					console.log(error);
				}
			});
		}
	}
}
