﻿function initBook(){
	$("#btn-fix").click(function(){

		call_hotai_api("LINELCS02_Q03",{  
			"LICSNO": Connection.client_info.vehicle_number
		},function(data){
			if(data.BOOKDATA.length>0){
				//有維修預約
				
				fix_log(data);
				$("#book-log").dialog("open");
				$("#book-log").scrollTop(0);
				$('.all').show()
			}else{
				//維修預約開啟
				$("#book-menu").dialog("open");
				$('.all').show()

				$('#cust-name').val(Connection.client_info.name);
				$('#cust-phone').val(Connection.client_info.PHONE);
				$('#cust-vehicle-number').html(Connection.client_info.vehicle_number);

				$('#service-factory').unbind('change');
				$('#service-factory').on('change', function(){

					$('#service-date').html('<option value="" selected="selected" hidden>無可選日期</option>')
					$('#service-time').html('<option value="" selected="selected" hidden>無可選時段</option>')

					var target = $('#service-factory').val().split('-');
					if(target.length==2){ 
						call_hotai_api('LINELCS02_Q02', {  
							"DLRCD": target[0] || Connection.service_info.DLRCD,
							"BRNHCD": target[1] || Connection.service_info.BRNHCD,
							"USERID": Connection.service_id
						}, function(data){
							var date_time = {}; //Object.keys(a)
							data.AVITIME.forEach(function(item){
								if(date_time.hasOwnProperty(item.ORDERDT)){
									if(!date_time[item.ORDERDT].includes(item.TIME_SET)){
										date_time[item.ORDERDT].push(item.TIME_SET)
									}
								}else{
									date_time[item.ORDERDT] = [item.TIME_SET] 
								}
							});
							$('#service-date').html('');
							$('#service-date').append(Object.keys(date_time).map(function(item){
								return '<option '+ 'value="' + item +'">' + item + '</option>';
							}).join(''));

							$('#service-date').unbind('change');
							$('#service-date').on('change', function(){
								$('#service-time').html('');
								$('#service-time').append(date_time[$('#service-date').val()].map(function(item){
									return '<option '+ 'value="' + item +'">' + item + '</option>';
								}).join(''));
							});
							$('#service-date').trigger('change');
						})
					}
				});

				call_hotai_api('LINELCS02_Q01', '{}', function(data){
					//地區綁服務廠 { area : [factories], }
					var area_factory = {};
					data.BRNHMF.forEach(function(item){
						if(area_factory.hasOwnProperty(item.ZIPNM)){
							if(!area_factory[item.ZIPNM].includes(item.DLRCD +'-'+ item.BRNHCD)){
								area_factory[item.ZIPNM].push(item.DLRCD +'-'+ item.BRNHCD)
							}
						}else{
							area_factory[item.ZIPNM] = [item.DLRCD +'-'+ item.BRNHCD] 
						}
					});
					$('#service-area').unbind('change');
					$('#service-area').on('change', function(){

						$('#service-date').html('<option value="" selected="selected" hidden>請選擇服務廠</option>')
						$('#service-time').html('<option value="" selected="selected" hidden>請選擇服務廠</option>')

						var target = $('#service-area').val();

						$('#service-factory > option').hide();
						area_factory[target].forEach(function(item){
							$('#service-factory > option[value="'+item+'"]').show()
						});
						$('#service-factory').val("");
					});
					
					var selectList = data.BRNHMF.map(function(item){
						//地區
						if(Connection.service_info.BRNHCD == item.BRNHCD && Connection.service_info.DLRCD == item.DLRCD) {
							$('option[text="' + item.ZIPNM + '"]').attr('selected','selected')
						}
						//服務廠
						return '<option '+
							(Connection.service_info.BRNHCD == item.BRNHCD && Connection.service_info.DLRCD == item.DLRCD ? 
								'selected="selected"' : '') +
							'value="' + item.DLRCD +'-'+ item.BRNHCD +'">' +
							item.BRNHNM + '</option>';
					}).join('');
					$('#service-factory').append(selectList);
					
				},"該服務廠沒有可選日期");
				//$("#book-menu").toggle();
			}
		})
	});
	$('#book-submit').click(function(){
		var target = $('#service-factory').val().split('-');
		call_hotai_api('LINELCS02_I01', {  
			"LICSNO": Connection.client_info.vehicle_number,
			"DLRCD": target[0] || Connection.service_info.DLRCD,
			"BRNHCD": target[1] || Connection.service_info.BRNHCD,

			"BKDT": $('#service-date').val().replace(/\//g,'-'),
			"USRID": Connection.service_id,	
			"BKSSEC": $('#service-time').val(),
			//固定寫1
			"OPTP": "1", 
			//hardcore now 里程數
			"RTPTML": "0",
			"CONTPSN": Connection.client_info.name,
			"CONTTEL": Connection.client_info.PHONE,
			"CALLOUTSEC": $('#cust-contacttime').val(),
			"REMARK": $('#service-memo').val(),
			"CRTPGID": "LINELCS02",
			"GVTYPE": $('#cust-wait').val()
			}, function(data){
				console.log(data);
				var retText = 
					'為您預約維修: \n' +
					'日期:' + $("#service-date").val() + '\n' +
					'時段:' + $("#service-time").val() + '\n' +
					'服務廠:' + $("#service-factory").val();
				
				Connection.send_text(retText);
				$('#book-menu').dialog('close');
				$('.all').hide();
			});
	});
	$('#book-reset').click(function(){
		$('#service-area').val(0)
		$('#service-factory').val('');
		$('#service-date').html('<option value="" selected="selected" hidden>請選擇服務廠</option>')
		$('#service-time').html('<option value="" selected="selected" hidden>請選擇服務廠</option>')
		$('#service-memo').val('')
	});

	//取車方式按鈕

	// $("#cust-wait-btn").click(function(){
	// 	var custWait = $('#cust-wait').val();
	// 	this.innerText = custWait=="A" ? 'Ｘ 完工通知':'Ｏ 在場等候';
	// 	$('#cust-wait').val(custWait=="A"?"C":"A");
	// });


	// $("#btn-booklog").click(function(){
	// 	call_hotai_api("LINELCS02_Q03",{  
	// 		"LICSNO": Connection.client_info.vehicle_number
	// 	},function(data){
	// 		if(data.BOOKDATA.length>0){
	// 			//塞資料
	// 			data = data.BOOKDATA[0];
	// 			$('#booklog_carno').html(data.LICSNO);
	// 			$('#booklog_factory').html(data.BRNHNM);
	// 			$('#booklog_content').html(data.REFCDNM);
	// 			$('#booklog_time').html(data.BKDT);
	// 			$('#booklog_name').html(data.CONTPSN);
	// 			$('#booklog_phone').html(data.CONTEL);
	// 			$('#booklog_other').html(data.REMARK);
	// 			var timezone = 
	// 				data.CALLOUTSEC == "1" ? "08:30-12:00" :
	// 				data.CALLOUTSEC == "2" ? "13:00-17:30" :
	// 				data.CALLOUTSEC == "3" ? "18:00-19:30" :
	// 				data.CALLOUTSEC == "4" ? "任何時段" :
	// 				/* "5" or others */ "無須連絡電話"
	// 			$('#booklog_timezone').html(timezone);

	// 			//取消預約
	// 			$('#cancel_reservation').unbind('click');
	// 			$('#cancel_reservation').click(function(){
	// 				call_hotai_api("LINELCS02_D01", {  
	// 					"SKEY": data.SKEY,
	// 					"LICSNO": data.LICSNO,
	// 					"CRTPGID": "USP_LINELCS02_D01",
	// 					"DLRCD": data.DLRCD,
	// 					"BRNHCD": data.BRNHCD,
	// 					"WORKNO": data.WORKNO
	// 				}, function(d){
	// 					// 已為您取消 yyyy/mm/dd hh:mm 於 XX廠 的 OO保養 預約"
	// 					Connection.send_text("已為您取消 " + data.BKDT + ' ' + data.BKSSEC + 
	// 					" 於 " + data.BRNHNM + " 的 " + data.REFCDNM + " 預約");
	// 					$('#book-log').toggle();
	// 				});
	// 			});
	// 			$('#book-log').toggle();
	// 		}else{
	// 			alert("沒有預約記錄");
	// 		}
	// 	});
	// });
}
function fix_log(data){
	//塞資料
	data = data.BOOKDATA[0];
	$('#booklog_carno').html(data.LICSNO);
	$('#booklog_factory').html(data.BRNHNM);
	$('#booklog_content').html(data.REFCDNM);
	$('#booklog_time').html(data.BKSSEC);
	$('#booklog_name').html(data.CONTPSN);
	$('#booklog_phone').html(data.CONTEL);
	$('#booklog_area').html(data.ADDR);
	$('#booklog_other').html(data.REMARK);

	$('#booklog_date').html(data.BKDT);
	var type = 
	data.GVTYPE == "A" ? "在廠等候" :
	data.GVTYPE == "C" ? "完工通知" : ""
	$('#booklog_type').html(type);


	var timezone = 
		data.CALLOUTSEC == "1" ? "08:30-12:00" :
		data.CALLOUTSEC == "2" ? "13:00-17:30" :
		data.CALLOUTSEC == "3" ? "18:00-19:30" :
		data.CALLOUTSEC == "4" ? "任何時段" :
		/* "5" or others */ "無須連絡電話"
	$('#booklog_timezone').html(timezone);

	//取消預約
	$('#cancel_reservation').unbind('click');
	$('#cancel_reservation').click(function(){
		call_hotai_api("LINELCS02_D01", {  
			"SKEY": data.SKEY,
			"LICSNO": data.LICSNO,
			"CRTPGID": "USP_LINELCS02_D01",
			"DLRCD": data.DLRCD,
			"BRNHCD": data.BRNHCD,
			"WORKNO": data.WORKNO
		}, function(d){
			// 已為您取消 yyyy/mm/dd hh:mm 於 XX廠 的 OO保養 預約"
			Connection.send_text("已為您取消 " + data.BKDT + ' ' + data.BKSSEC + 
			" 於 " + data.BRNHNM + " 的 " + data.REFCDNM + " 預約");
			$('#book-log').dialog('close');
			$('.all').hide()
		});
	});
	//$('#book-log').toggle();
}