﻿$( function() {
	// alert(navigator.userAgent)
	// emotion_setting();
	menu_setting();
	setLightbox()

	// var startY, endY;
	// document.body.addEventListener('touchstart', function (e) {
	// 	startY = e.touches[0].pageY;
	// });
	// document.body.addEventListener('touchmove', function (e) {
	//	 console.log($("body").scrollTop());
	// 	 /*if($("body").scrollTop() == 0){
	// 	 	e.preventDefault(); //阻止默认的处理方式(阻止下拉滑动的效果)
	// 	 }*/
	// 	endY = e.touches[0].pageY;  //记录手指触摸的移动中的坐标
	// 	//手指下滑，页面到达顶端不能继续下滑
	// 	if(endY>startY&& $(window).scrollTop()<0){
	// 		e.preventDefault();
	// 	}
	//   	//手指上滑，页面到达底部能继续上滑
	// 	if(endY<startY&& $(window).scrollTop()+ 
	// 		$(window).height()>$('body')[0].scrollHeight){
	// 		e.preventDefault();
	// 	}
	// }, {passive: false});

	$("#talk_tricks_container").delegate( ".talk_trick", "click", function() {
		$(".input").val($(this).text());
		$(".input").trigger('change');
		$("#talk_tricks_container").toggleClass("enable"); 
	});
	$("#talk_tricks_container").delegate( ".talk_tricks_edit", "click", function() {
		let talk_trick_text = [];
		$(".talk_tricks_edit").parent().parent().find(".talk_trick").each(function(i,item){
			talk_trick_text.push($(item).text());
		});
		
		let editor_str = talk_trick_text.map(function(item){
			return "<div>"+
					"	<input class='edited-trick' type='text' value='"+item+"' />"+
					"	<span class='del'>DELETE</span>"+
					"</div>"
		}).join("");
		console.log(talk_trick_text);
		$("#talk_tricks_container").attr("lock",true);
		$("#talk_tricks_editor").html(editor_str+(talk_trick_text.length<5?"<div class='new'>new</div>":""));
		$("#talk_tricks_editor").dialog("open");
		$(".all").show();
		
		
		$(".input").val($(this).text());
		//$("#talk_tricks_container").toggleClass("enable"); 
	});
	$("#talk_tricks_container").delegate( ".talk-tricks-close", "click", function() {
		$("#talk_tricks_container").toggleClass("enable"); 
		reset_console_height();
	});
	$("#talk_tricks_editor").delegate( ".del", "click", function() {
		$(this).parent().remove();
		if($('#talk_tricks_editor').children().find('input').length < 5 ){
			$('#talk_tricks_editor > .new').show();
		}
	});
	$("#talk_tricks_editor").delegate( ".new", "click", function() {
		$(this).before(
			"<div>"+
			"	<input class='edited-trick' type='text' value='' />"+
			"	<span class='del'>DELETE</span>"+
			"</div>"
		);
		if($('#talk_tricks_editor').children().find('input').length > 4 ){
			$(this).hide();
		}
	});
	$('#cust-info').dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "auto", width: "100%", modal: true
	});
	$("#dialog-normal-talk-tricks").dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "auto", width: "100%", modal: true, top: '53px'
	});
	$("#dialog-change-manager").dialog({autoOpen: false});

	$("#talk_tricks_editor").dialog({
			title: "修改相應回答話術",
			draggable : true, resizable : false, autoOpen : false,
			height : "auto", width : "90vw", modal : true,
			buttons : [{
				text: "修改", 
				click: function() { 
					$("#talk_tricks_container").attr("lock",false);
					$(this).dialog("close");
					$('.all').hide()
					let ans_ID = $("#talk_tricks_editor").attr("ans_ID");
					let talk_tricks = [];
					$("#talk_tricks_editor").find("input").each(function(i,item){
						talk_tricks.push($(item).val());
					})
					talk_tricks_setting(talk_tricks);
					Connection.update_talk_tricks(ans_ID,talk_tricks);
				}
			},{
				text: "取消", 
				click: function() { 
					$("#talk_tricks_container").attr("lock",false);
					$(this).dialog("close");
					$('.all').hide()
				}
			}]
		});
	$('#search_box').keyup(function(e){
		var input = $('#search_box').val();
		$('.cs_manager_list > .cs_manager_list_container > .list_element').attr("style", "display: none;")
		if(input){
			var list = Connection.conversation_list;
			Object.keys(list).forEach(function(item){
				if(list[item].conversation_title.includes(input) || list[item].customer_nickname.includes(input))
					$('.cs_manager_list > .cs_manager_list_container > .list_element[customer_id="' + item + '"]').attr("style", "display: block;")
			});
		}else{
			$('.cs_manager_list > .cs_manager_list_container > .list_element').attr("style", "display: block;")
		}
	});
	$('#search_box').on('focusout', function(e){
		$(this).val('');
		$(this).trigger('keyup');
	})

	var isAndroid = navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Adr') > -1; //android终端
	if(isAndroid){
		$('#btn-camera').hide();
	}
	$("#btn-camera").click(function(){
		$("#take_picture").trigger("click");
	});
	$('#btn-photo').click(function(e){
		$("#upload_picture").trigger("click");
	});
	$('#btn-change').click(function(e){
		changeManager();
	});
	$('#btn-phone').click(function(e){
		call_customer();
		$('.all').show();
	});
	$('#btn-talk-tricks').click(function(e){
		normal_tricks('.input.msg')
	});
	$('.edit-normal-trick').click(function(e){
		$('.trick').toggleClass('enable')
		$(this).toggleClass('enable')
		$('.save-normal-trick').toggleClass('enable')
		$('textarea.trick').trigger('change');
	})
	$('.save-normal-trick').click(function(e){
		$('.trick').toggleClass('enable')
		$(this).toggleClass('enable')
		$('.edit-normal-trick').toggleClass('enable')
		$('textarea.trick').each(function(){
			$(this).parent().find('div.trick').html($(this).val())
			//$(this).parent().find('div.trick').height($(this).height());
		})
		var tmp = [];
		$("#tab-dia-birth textarea.trick").each(function(){tmp.push($(this).val());});
		Connection.update_talk_tricks('NORMAL_BIRTH',tmp);
		tmp = [];
		$("#tab-dia-fend textarea.trick").each(function(){tmp.push($(this).val());});
		Connection.update_talk_tricks('NORMAL_FEN',tmp);
		tmp = [];
		$("#tab-dia-hotai textarea.trick").each(function(){tmp.push($(this).val());});
		Connection.update_talk_tricks('NORMAL_HOTAI',tmp);
		tmp = [];
		$("#tab-dia-other textarea.trick").each(function(){tmp.push($(this).val());});
		Connection.update_talk_tricks('NORMAL_OTHER',tmp);
		
	})
	$('.btn-edit-name').click(function(e){
		edit_nickname();
	})

	//維修預約dialog(無資料時)
	$("#book-menu").dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "400px", width: "100%", modal: true, position: { my: "center", at: "left+800px top+330px ", of: window  }
	});

	//維修預約dialog(有資料時)
	$("#book-log").dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "700px", width: "100%", modal: true, position: { my: "center", at: "left+800px top+400px ", of: window  },
		// focus:function(e,ui) {
		// 	$("#booklog_carno").focus();
		// }
	});

	$('div.trick').unbind('click')
	$('div.trick').click(function(e){
		$(target).val($(this).html())
		$(target).trigger('change');
		$('#dialog-normal-talk-tricks').dialog('close');
		$('.all').hide();
	})
	$('div.ui-dialog > div.ui-dialog-titlebar > button[title="Close"]').click(function(e){
		$('.all').hide()
	})
})


function to_login(){
	
	call_hotai_api("USER_LOGIN",{
		"USERID": $("#username").val(),
		"PWD": $("#password").val()
	},function(logindata){

		console.log('logindata',logindata)
		if(logindata.isSuccess && logindata.result.FLAG != "Y"){
			warningMsg('登入失敗', logindata.result.rtnMsg+'，請至<a style="word-break: break-all;" href="#" onclick="window.open(\'https://htsr.hotaimotor.com.tw/LINENOTIFYAPI_TEST/LOGIN/login\')">https://htsr.hotaimotor.com.tw/LINENOTIFYAPI_TEST/LOGIN/login</a>綁訂後使用');
		}
		else if(!logindata.isSuccess){
			$('.btn-login').nextAll().remove();
			$('.btn-login').after('<div style="color:red;text-align:left;margin: 0px 12vw; font-size:18px;">' + logindata.result.rtnMsg + '</div>');
			$('.all').hide();
		}
		else{
			logindata = logindata.result;
			
			let login_info = logindata;
			call_hotai_api("LINE006_Q01",{
				DLRCD: login_info.DLRCD,
				BRNHCD: login_info.BRNHCD,
				USERID: login_info.USERID,
				ECHOTITLECD: login_info.ECHOTITLECD,
				FRAN: login_info.FRAN
			},function(data){
				let responsibility_info = data
				$(".login_panel").hide();
				$(".after_login").show();
				let service_id = $("#username").val();
				login_info.PICURL = "https://lexus-cs.herokuapp.com/images/cs_icon.png";
				login_info.PHONE = null;
				
				let responsibility_data = responsibility_info.USERINFO.map(function(item){
					return {
						USERID: item.USERID,
						ENCYID: item.ENCYID,
						NICKNAME: item.NICKNAME,
						CARNM: item.CARNM,
						LICSNO: item.LICSNO,
						PICURL: item.PICURL,
						MOBILE: item.MOBILE,
						FENDAT: item.FENDAT,
						UENDAT: item.UENDAT,
						BRTHDT: item.BRTHDT,
						FFLAG: item.FFLAG,
						UFLAG :item.UFLAG,
						BIRFLAG: item.BIRFLAG
					};
				});
				
				set_manager_socket(service_id,login_info,responsibility_data,logindata);
			});
		}
	});
	
}


//設定 Socket 
function set_manager_socket( service_id, manager_data, responsibility_data,logindata){
	
	Connection = {}
	
	Connection.init = function(){
		Connection.socket = io(socket_server_ip);
		
		Connection.end_point = "service" ;
		Connection.client_id  = "";
		Connection.service_id = service_id?service_id:UUID();
		Connection.client_info = {
			"id":"",
			"name":"",
			"avator":"/images/avator.png",
			"PHONE":""
		};;
		Connection.service_info = {
			"id": logindata.USERID,
			"name": logindata.USERNM,
			"avator": logindata.PICURL,
			"PHONE": logindata.PHONE,
			"sex": logindata.SEX
		};

		$('.header-title').html('<div class="header-title">專屬專員 - ' + logindata.USERNM + '</div>');

		Connection.conn = false ;
		Connection.talks = [];
		Connection.talks_history_cursor = 0;
		Connection.update = true;
		
		Connection.set_listener();
		
		common_conn_setting(Connection);
		
		console.log('init')
		Connection.conversation_list = {};
		responsibility_data.forEach(function(item){
			Connection.conversation_list[item.ENCYID] = {};
		});

		Connection.socket.emit("register service",{
			type : Connection.end_point,
			service_id : Connection.service_id,
			manager_data : manager_data,
			responsibility_data : responsibility_data
		});
	}
	
	Connection.set_listener = function(){
		Connection.socket.on('enter', function (data) {
			console.log('data',data)
			try {
				let conversation_data = data[0][0];
				Connection.client_info = JSON.parse(conversation_data.customer_data);
				var target = Connection.conversation_list[Connection.client_info.id];
				//console.log('target',target)

				Connection.client_info.detail = target.detail;
				//need_notify  Y:需要提醒	N:不需提醒
				//notify       Y:待提醒		N:已提醒
				Connection.client_info.notify = {
					birth_need_notify: target.birth_need_notify || "Y",
					birth_notify: target.birth_notify || "Y",
					fend_need_notify: target.fend_need_notify || "Y",
					fend_notify: target.fend_notify || "Y",
					uend_need_notify: target.uend_need_notify || "Y",
					uend_notify: target.uend_notify || "Y"
				};
				//console.log('client_info.notify')
				//todo 太醜了
				Connection.service_info = JSON.parse(conversation_data.manager_data);
				Connection.service_info.BRNHCD = logindata.BRNHCD;
				Connection.service_info.COMPID = logindata.COMPID;
				Connection.service_info.COMPSIMPNM = logindata.COMPSIMPNM;
				Connection.service_info.DEPTSIMPNM = logindata.DEPTSIMPNM;
				Connection.service_info.DLRCD = logindata.DLRCD;
				Connection.service_info.ECHOTITLECD = logindata.ECHOTITLECD;
				Connection.service_info.FRAN = logindata.FRAN;

				//$('#btn-call').attr('onclick','location.href="tel:'+Connection.client_info.PHONE+'";')
			}catch(err) {
				console.log(err);
			}
			// console.log("Connection.service_info",Connection.service_info);
			// console.log("Connection.client_info",Connection.client_info);
			
			Connection.conn = true;
			my_console("【"+Connection.client_id+"-"+Connection.service_id+"】 連線成功");
			console.log(
				"對話對象所見頁面",window.location.origin + "/cust.do"
					+"?c="+b64EncodeUnicode(Connection.client_id)
					+"&s="+b64EncodeUnicode(Connection.service_id)
			)
			if(Connection.talks_history_cursor==0){
				Connection.socket.emit("get history",{
					"limit":3
				});
			}
			// var notify = Connection.client_info.notify;
			// if((notify.birth_need_notify=="Y" && notify.birth_notify=="N") || 
			//     (notify.fend_need_notify=="Y" && notify.fend_notify=="N")){
			// 	$('#btn-custinfo')[0].style.backgroundColor = 'red';
			// }
		});
	
		Connection.socket.on('leave', function () {
			console.log("SocketEvent:Leave");
			// console.log("change_talk_target",{
			// 	"leave":Connection.client_id,
			// 	"join":Connection.next_client_id
			// });
			if(Connection.next_client_id){
				Connection.talks = [] ;
				Connection.talks_history_cursor = 0;
				Connection.socket.emit("enter", {
					type : Connection.end_point,
					client_id : Connection.next_client_id,
					service_id : Connection.service_id
				});
			}
			Connection.client_id = Connection.next_client_id;
			Connection.next_client_id = null;
		});
		
		Connection.socket.on('reconnect', function () {
			console.log('reconnect');
			Connection.conn = true;
			my_console("重新連接");
			//$("#console").html('<div class="loading_div"><img src="/images/loading.gif" /></div>');
			Connection.socket.emit("enter",{
				type : Connection.end_point,
				client_id : Connection.client_id,
				service_id : Connection.service_id,
			});
			Connection.socket.emit("register service",{
				type : Connection.end_point,
				service_id : Connection.service_id,
				manager_data : manager_data,
				responsibility_data : responsibility_data
			});
		});
		
		Connection.socket.on('update conversation list', function (data) {
			//console.log("receive conversation list",data)
			setTimeout(function(){
				Connection.conversation_list = Connection.conversation_list || {};
				var newdata = [];
				data[0].forEach(function(item){
					if(Connection.conversation_list.hasOwnProperty(item.customer_id)){
						item.detail = item.detail || Connection.conversation_list[item.customer_id].detail;
						Connection.conversation_list[item.customer_id] = item;
						newdata.push(item)
					}
				});
				
				update_conversatoin_list(newdata);
			},100);
		});

		
		//########NORMAL#######
		Connection.socket.on('normal talk trick', function (data) {
			//console.log('normal talk trick');
			//console.log(data);
			
			//["普通話術1", "普通話術2", "生日快樂1", "生日快樂2", "續保話術1", "該續保了2", "其他1", "其他話術"]
			Connection.normal_talk_trick = data;
			if(data==null)return;
			data.forEach(function(item){
				
				item.talk_tricks = JSON.parse(item.talk_tricks);
				if(item.dialog_id=="NORMAL_BIRTH"){
					let talk_trick_html = item.talk_tricks.map(function(talk_trick_item,i){
						return '<div class="'+i+'"><h3>生日話術'+(i+1)+'</h3>'
							+'<div class="trick enable">'+talk_trick_item+'</div>'
							+'<textarea class="trick" style="">'+talk_trick_item+'</textarea></div>';
					}).join("");
					$('#tab-dia-birth').html(talk_trick_html);
				}
				if(item.dialog_id=="NORMAL_FEN"){
					let talk_trick_html = item.talk_tricks.map(function(talk_trick_item,i){
						return '<div class="'+i+'"><h3>續保話術'+(i+1)+'</h3>'
							+'<div class="trick enable">'+talk_trick_item+'</div>'
							+'<textarea class="trick" style="">'+talk_trick_item+'</textarea></div>';
					}).join("");
					$('#tab-dia-fend').html(talk_trick_html);
				}
				if(item.dialog_id=="NORMAL_HOTAI"){
					let talk_trick_html = item.talk_tricks.map(function(talk_trick_item,i){
						return '<div class="'+i+'"><h3>和泰提供'+(i+1)+'</h3>'
							+'<div class="trick enable">'+talk_trick_item+'</div>'
							+'<textarea class="trick" style="">'+talk_trick_item+'</textarea></div>';
					}).join("");
					$('#tab-dia-hotai').html(talk_trick_html);
				}
				if(item.dialog_id=="NORMAL_OTHER"){
					let talk_trick_html = item.talk_tricks.map(function(talk_trick_item,i){
						return '<div class="'+i+'"><h3>其他話術'+(i+1)+'</h3>'
							+'<div class="trick enable">'+talk_trick_item+'</div>'
							+'<textarea class="trick" style="">'+talk_trick_item+'</textarea></div>';
					}).join("");
					$('#tab-dia-other').html(talk_trick_html);
				}
			});
			$('textarea.trick').trigger('change')
		});
	}
	
	Connection.change_customer = function(client_id){
		console.log('change_customer',client_id);
		Connection.next_client_id = client_id;
		Connection.socket.emit('leave',{
			type : Connection.end_point,
			client_id : Connection.client_id,
			service_id : Connection.service_id
		});
	}
	
	Connection.reiceive_msg = function (message){
		console.log(message)
		if(message.ans_ID&&!$("#talk_tricks_container").attr("lock")){
			$("#talk_tricks_editor").attr("ans_ID",message.ans_ID);
		}
		if(message.talk_tricks){
			talk_tricks_setting(message.talk_tricks);
			$("#talk_tricks_container").addClass("enable"); 
		}
		if(!message.broadcast){
			if($('#console > .dialog[timestamp]').length){
				var pretime = $('#console > .dialog[timestamp]:last').attr('timestamp');
				var thistime = get_message_time(message.time);
				pretime = get_message_time(pretime);

				var date_str = "";
				if(pretime.fulldate != thistime.fulldate){
					produce_dialog_seperate('換日');
					if(pretime.year != thistime.year){
						date_str+=thistime.year+'/';
					}
					date_str+=thistime.date;
					produce_dialog_seperate(date_str);
				}
			}
			$("#console").append(produce_dialog_element(message));
			$("#console").scrollTop($('#console')[0].scrollHeight);
		}
	}
	
	Connection.update_talk_tricks = function(ans_ID,talk_tricks){
		console.log("update talk trick");
		console.log(ans_ID);
		console.log(talk_tricks);
		Connection.socket.emit('update talk trick',{
			dialog_id : ans_ID,
			talk_tricks : talk_tricks
		});
	}
	
	Connection.init();
	$('.all').hide();
}

function update_conversatoin_list(conversatoin_data){
	conversatoin_data.sort(function(a,b){
		return a.last_talk_time < b.last_talk_time ? 1 : -1;
	})
	//console.log(conversatoin_data)
	//console.log("draw_conversatoin_list");
	conversatoin_data.forEach(function(item){
		var detail = item.detail || {};
		var BIRFLAG = item.birth_need_notify == "Y" &&
						item.birth_notify == "Y" &&
						DateDiff(detail.BRTHDT) < 15,
			FFLAG = item.fend_need_notify == "Y" &&
					item.fend_notify == "Y" &&
					DateDiff(detail.FENDAT) < 15;
		
		detail = '<div class="notify">' + 
					(BIRFLAG?'<img src="/images/cake.png" style="height:20px>':"") + 
					(FFLAG?'<img src="/images/insurance.png" style="height:20px">':"") + 
				'</div>';


		var div_html =
				"<div class='list_element "+(Connection.client_id == item.customer_id?"active":"")+"'"
				+"		 customer_id='"+item.customer_id+"'>"
				+'		<div class="img" alt="">'
				+'			<img src="'+item.avator+'" alt="">'
				+'		</div>'
				+'		<div class="chat_body">'
				+'			<div class="title">'
				+					item.conversation_title + detail
				+'			</div>'
				+'			<div class="name" customer_id="' + item.customer_id+ '">'
				+					item.customer_nickname
				+'			</div>'
				+'			<div class="msg">'
				+					item.last_message
				+'			</div>'
				+'		</div>'
				+		"<div class='timestamp'>"+displayChatTime(item.last_talk_time)+"&nbsp;</div>"
				+		((item.manager_unread&&item.customer_id!=Connection.client_id)?"<div class='unread'><div class='note-text'>"+item.manager_unread+"</div></div>":"")
				+'	</div>';

		var element= '.cs_manager_list>.cs_manager_list_container>.list_element[customer_id="'+item.customer_id+'"]';


		if($(element).length==1){
			$(element).remove();
			$('.cs_manager_list > .cs_manager_list_container > .list_element:first').before(div_html)
		}else{
			
			if($(".list_element").length==0){
				$('.cs_manager_list > .cs_manager_list_container').html(div_html);	
			}else{
				$(".cs_manager_list > .cs_manager_list_container > .list_element:last").after(div_html);
			}
		}
	})

	// var notify = Connection.client_info.notify;
	// if(notify){
	// 	if((notify.birth_need_notify=="Y" || notify.birth_notify=="Y") && 
	// 		(notify.fend_need_notify=="Y" || notify.fend_notify=="Y")){
	// 		// $('#btn-custinfo')[0].style.backgroundColor = '#ef3';
	// 	}
	// }
}

function normal_tricks(target){
	$('#dialog-normal-talk-tricks').dialog('open');
	$('.all').show();

	$('div.trick').unbind('click')
	$('div.trick').click(function(e){
		$(target).val($(this).html())
		$(target).trigger('change');
		$('#dialog-normal-talk-tricks').dialog('close');
		$('.all').hide();
	})
}

// 一般話術
function tricks(type){
	type = type || "other";

	// Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById('tab-'+ type).style.display = "block";
    $('#Tab-'+ type).addClass('active')
}

// function select_trick(event){
// 	console.log(event)
// 	if($('.txt').html() == "多人訊息"){
// 		$('.fr-element.fr-view > p:first-child').append(event.target.value);
// 		//$('#dialog-normal-talk-tricks').dialog('close');
// 	}else{
// 		$('.input.msg').val(event.target.value);
// 		//$('#normal_talk_tricks').toggle();
// 	}
// 	$('#dialog-normal-talk-tricks').dialog("close");
// }

//金牌話術
function talk_tricks_setting_with_message_id(message_id){
	Connection.talks.forEach(function(item){
		if(item.message_id == message_id ){
			if(item.talk_tricks){
				talk_tricks_setting(item.talk_tricks);
			}else{
				$("#talk_tricks_container").removeClass("enable");
				
				reset_console_height();
			}
			return ;
		}
	})
}
function talk_tricks_setting(data){
	
	let edit_div = "<div style='line-height: 30px;text-align: center;'><div class='talk_tricks_edit'></div><div class='talk-tricks-title'>金牌話術</div><img class='talk-tricks-close' src='/images/white-close.png' alt='' /></div>";
	let talk_tricks_str = data.map(function(item){
		return "<div class='talk_trick'><a>"+item+"</a></div>";
	}).join("");
	if(!$("#talk_tricks_container").attr("lock")){
		$("#talk_tricks_container").html(edit_div + talk_tricks_str);
		$("#talk_tricks_container").addClass("enable");
		
		reset_console_height()
	}
	
}

//功能選單
function menu_setting(){

	//預約流程
	initBook();
	$('#btn-custinfo').click(function(){
		call_hotai_api("LINELCS01_Q01",{
			"ENCYID": Connection.client_id
		},function(data){
			var data = data.USERDATA[0];
			$('#custinfo_name').html(Connection.client_info.name || '-');
			$('#custinfo_birthday').html(data.BIRTHDAY || '-');
			$('#custinfo_address').html(data.ADDR || '-');
			$('#custinfo_carno').html(Connection.client_info.vehicle_number?Connection.client_info.vehicle_number:"-");
			$('#custinfo_phone').html(data.MOBILE || '-');
			$('#custinfo_uendat').html(data.UENDAT || '-');
			$('#custinfo_fendat').html(data.FENDAT || '-');
			$('#custinfo_redldt').html(data.REDLDT || '-');
			$('#custinfo_sfx').html(data.SFX || '-');
			$('#custifo_brkds').html(data.BRKDS || '-');
			$('#custifo_rtptml').html(data.RTPTML || '-');
			$('#custinfo_advise').html(data.NXRPMO || '無建議');
			$('#custifo_rtptdt').html(data.RTPTDT || '無記錄');

			// button?
			// 在14天內且Flag==Y
			var client_setting = Connection.conversation_list[Connection.client_id];
			var hasbutton = (DateDiff(data.BIRTHDAY)<15 && 
							"Y" == client_setting.birth_need_notify) &&
							"Y" == client_setting.birth_notify;
			if(hasbutton){
				$('#custinfo_birthday_title').html('生日<span class="notify" onclick="notify(\''+Connection.client_id+'\',\'birth\')"><img src="/images/notify.png">生日推播</span>');
				$('#custinfo_birthday_title').parent().children('.right').attr('style', 'color:red;');
			}else{
				$('#custinfo_birthday_title').html('生日');
				$('#custinfo_birthday_title').parent().children('.right').attr('style', '');
			}
			hasbutton = moment(data.FENDAT.replace(/\//g,'')).diff(moment(new Date())) < 15 * (1000*3600*24) && 
						"Y" == client_setting.fend_need_notify &&
						"Y" == client_setting.fend_notify;
			if(hasbutton){
				$('#custinfo_fendat_title').html('強制險到期日<span class="notify" onclick="notify(\''+Connection.client_id+'\',\'fend\')"><img src="/images/notify.png">續保推播</span>');
				$('#custinfo_fendat_title').parent().children('.right').attr('style', 'color:red;');
			}else{
				$('#custinfo_fendat_title').html('強制險到期日');
				$('#custinfo_fendat_title').parent().children('.right').attr('style', '');
			}
			$('#cust-info').dialog('open');
			$('.all').show();
		});
	})
}

function DateDiff(birthday){
	var today = new Date();
	var b = moment(today)

	if(!birthday) return 99;

	if(birthday.length==8 && !birthday.includes('/')){
		birthday = moment(birthday).format('YYYY/MM/DD');
	}
	birthday = birthday.split("/");
	
	if(birthday.length==2){
		birthday = (birthday[0].length == 2 ? birthday[0] : "0" + birthday[0]) +
				(birthday[1].length == 2 ? birthday[1] : "0" + birthday[1]);
	}else if(birthday.length==3){
		birthday = (birthday[1].length == 2 ? birthday[1] : "0" + birthday[1]) +
				(birthday[2].length == 2 ? birthday[2] : "0" + birthday[2]);
	}else{
		return 999;
	}

	var result1 = moment((today.getFullYear()+1)+birthday).diff(b, 'days');
	var result2 = moment((today.getFullYear())+birthday).diff(b, 'days')

	return result1 < 365 ? result1 : result2;
}

function changeManager(){

	if(!Connection.client_id) return;

	call_hotai_api("LINE006_Q00",{
		"ENCYID": Connection.client_id,
		"FRAN": "L"
	}, function(data){
		var managers = [];
		data = data.CSINFO[0];
		console.log()
		if(""!==data.CRSALR && Connection.service_id !== data.CRSALR){
			managers.push({
				"id": data.CRSALR,
            	"name": data.CRSALRNM
			});
		}
		if(""!==data.WHSRVNO && Connection.service_id !== data.WHSRVNO){
			managers.push({
				"id": data.WHSRVNO,
            	"name": data.WHSRVNM
			});
		}
		if(managers.length == 1){
			$('#dialog-change-manager-content').html("是否結束您與用戶的對話，改由 "+managers[0].name +" 負責");
			$('#btn-change-manager').attr('style','');
			$('#btn-change-manager').attr('onclick','ConfirmChangeManager("'+Connection.client_id+'","'+managers[0].id+'");$("#dialog-change-manager").dialog("close");');
		}else{
			$('#dialog-change-manager-content').html("用戶暫時沒有其他負責專員");
			$('#btn-change-manager').attr('style','display:none;');
		}
	
		$("#dialog-change-manager").dialog("open");
		$('.all').show();
	});
}

function ConfirmChangeManager(customer_id, manager_id){
	//console.log(customer_id, manager_id);
	$('.all').hide();
	Connection.socket.emit('change customer',{
		customer_id: customer_id,
		manager_id: manager_id
	});
}

function reset_console_height(){
	
	let at_bottom=true;
	if($("#console").scrollTop()+$("#console").height()<$("#console")[0].scrollHeight-10){
		at_bottom=false
	}
	$("#console").height("calc( 100% - "+$(".control-bar").height()+"px - "+$(".header_content").height()+"px )");
	if(at_bottom){
		$("#console").scrollTop($("#console")[0].scrollHeight);
	}
}