﻿//need jquery && jquery-ui

$(function () {
	if(!Browser().match('Line')){
		// warningMsg('錯誤', "請從Line開啟專員服務連結",[{
		// 	text: "離開", 
		// 	click: function() { 
		// 		history.back()
		// 	}
		// }]);
		//return;
	}
	setLightbox();
	// emotion_setting();
	maintain_log_init();
	//IosPreventDefault();
	set_customer_socket();

	$("#dialog-login").dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "auto", width: "240", modal: true
	});
	$("#dialog-safty").dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "auto", width: "100%", modal: true
	});
	$("#dialog-hint").dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "auto", width: "100%", modal: true
	});
	//LEXUS服務小幫手
	$("#dialog-hint-service").dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "auto", width: "100%", modal: true, position: { my: "center", at: "left+800px top+500px ", of: window  }
	});
	//評分
	$("#dialog-score").dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "auto", width: "100%", modal: true, position: { my: "center", at: "left+800px top+500px ", of: window  }
	});
	//保修頁
	$('#maintain-page').dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "auto", width: "100%", modal: true, position: { my: "center", at: "left+800px top+500px ", of: window  }
	});
	$('#detail-page').dialog({
		draggable: false, resizable: false, autoOpen: false,
		height: "auto", width: "100%", modal: true
	});

	$(".header_content .txt").html(Connection.service_name);

	var isAndroid = navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Adr') > -1; //android终端
	if(isAndroid){
		$('#btn-camera').hide();
	}
});

//設定 Socket 
function set_customer_socket() {

	Connection = {}

	Connection.init = function (manager_id) {
		Connection.socket = io(socket_server_ip);

		Connection.end_point = "client";
		Connection.client_id = client_id_b64 ? b64DecodeUnicode(client_id_b64) : UUID();
		Connection.service_id = manager_id ? manager_id : service_id_b64 ? b64DecodeUnicode(service_id_b64) : UUID();
		Connection.client_info = {
			"id": "",
			"name": "",
			"avator": "/images/avator.png",
			"PHONE": ""
		};
		Connection.service_info = {
			"id": "",
			"name": "",
			"avator": "/images/avator.png",
			"PHONE": ""
		};;
		Connection.conn = false;
		Connection.talks = [];
		Connection.talks_history_cursor = 0;

		Connection.set_listener();
		common_conn_setting(Connection);

		Connection.socket.emit("enter", {
			type: Connection.end_point,
			client_id: Connection.client_id,
			service_id: Connection.service_id
		});

	}

	Connection.set_listener = function () {

		Connection.socket.on('enter', function (data) {
			console.log("data", data)

			try {
				let conversation_data = data[0][0];
				Connection.client_info = JSON.parse(conversation_data.customer_data);
				Connection.service_info = JSON.parse(conversation_data.manager_data);

			} catch (err) {
				console.log(err);
			}
			//console.log("Connection.service_info", Connection.service_info);
			//console.log("Connection.client_info", Connection.client_info);

			if (Connection.end_point == "client") {
				lexus_sys_talk("您好接下來將由" + Connection.service_info.name
					+ "專員為您服務，有任何問題都可以先留言，專員看到後會立即回覆");
			}

			Connection.conn = true;
			my_console("【" + Connection.client_id + "-" + Connection.service_id + "】 連線成功");
			Connection.socket.emit("register client", {});
			if (Connection.talks_history_cursor == 0) {
				Connection.socket.emit("get history", {
					"limit":3
				});
			}
			// Connection.socket.emit("get history",{
			// 	"skip": Connection.talks_history_cursor,
			// 	"limit":2
			// });
		});

		Connection.socket.on('reconnect', function () {
			Connection.conn = true;
			my_console("重新連接");
			//$("#console").html('<div class="loading_div"><img src="/images/loading.gif" /></div>');
			Connection.socket.emit("enter", {
				type: Connection.end_point,
				client_id: Connection.client_id,
				service_id: Connection.service_id
			});
		});

		Connection.socket.on('change customer', function (data) {
			console.log('change customer', data)
			if (data.manager_id !== Connection.service_id) {
				Connection.socket.emit("leave", {});
				Connection.init(data.manager_id);
				lexus_sys_talk("系統正在為您轉換專員");
			}
		})
	}

	Connection.reiceive_msg = function (message) {
		$("#console").append(produce_dialog_element(message));
		$("#console").scrollTop($('#console')[0].scrollHeight);
	}

	Connection.init();

}

