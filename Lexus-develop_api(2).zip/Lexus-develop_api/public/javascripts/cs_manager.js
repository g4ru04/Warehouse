//Only for cs_manager

$( function() {
	
	//送出按鈕
	$(".btn-search").click(function(){
		send_text_msg();
		$("#talk_tricks_container").removeClass("enable"); 
	});
	$("textarea.input.msg").keydown(function (e) {
		if (e.which == 13) {
			e.preventDefault();
			send_text_msg();
			$("#talk_tricks_container").removeClass("enable"); 
		}
	});
	$('textarea').on('change paste keyup', function(e){
		this.style.height = "";
		this.style.height = this.scrollHeight + "px";
	})
	
	//點擊note
	$(".list_element .note .tooltip").click(function(event){
		//頁面不觸發跳轉
		event.stopPropagation();
	});
	
	//List跳Dialog Dialog回到List
	$(".heder_service").click(function(){
		$(".cs_manager_list").toggleClass("current_view");
		$(".cs_manager_dialog").toggleClass("current_view");
		$(".cs_manager_list").toggleClass("hide_view");
		$(".cs_manager_dialog").toggleClass("hide_view");
		$('.active').toggleClass('active');
		$('.edit-cancel').trigger('click');
		Connection.socket.emit('leave',{
			type : Connection.end_point,
			client_id : Connection.client_id,
			service_id : Connection.service_id
		});
	});
	
	$(".cs_manager_list > .cs_manager_list_container" ).delegate( ".list_element", "click", function() {

		$(".list_element").removeClass("active");
		$(this).addClass("active");
		let customer_id = $(this).attr("customer_id");
		let customer_name = $(this).find(".title").text().split("/").pop();
		$(".cs_manager_list").toggleClass("current_view");
		$(".cs_manager_dialog").toggleClass("current_view");
		$(".cs_manager_list").toggleClass("hide_view");
		$(".cs_manager_dialog").toggleClass("hide_view");
		if(Connection.client_id!=customer_id){
			Connection.change_customer(customer_id);
			$(".cs_manager_dialog .header_content .txt").html(customer_name);
			$(".cs_manager_dialog .header_content .user-name").html(Connection.conversation_list[customer_id].customer_nickname || Connection.client_info.name);
			$("#console").html(
				'<div class="loading_div">'+
					'<img src="/images/loading.gif" />'+
				'</div>');
		}	
	});
	$('input.edit-name').on('change paste keyup', function(e){
		$('.edit-limit').html($('input.edit-name').val().length+'/10')
	})
	$('#btn-more').on('click', function(e){
		$('#btn-btns').toggleClass('btn-more')
		$('#btn-btns').toggleClass('btn-open')
		$('.box.high').toggle();
		// $('#console').toggleClass('higher')
		// if($('.box:first').is(':visible')){
		// 	$('#console').attr('style','height:calc(100% - '+(183+devicediff)+'px);')
		// }else{
		// 	$('#console').attr('style','height:calc(100% - '+(120+devicediff)+'px);')
		// }
		reset_console_height()
	})
	set_dialog_trigger();
} );

function apply_edit_nickname(event){
    targetevent = event;
	var target = event.srcElement.getAttribute('customer_id');

	Connection.socket.emit("edit customer name",{
		customer_id: target,
		manager_id: Connection.service_id,
		nickname: $('input[type="text"][customer_id="'+target+'"]').val()
	})

	$('input[customer_id="'+target+'"]').attr('style','display:none;');
	$('div.name[customer_id="'+target+'"]').attr('style','');
}

function edit_nickname(){
	var target = Connection.client_id;
	var nickname = $('.user-name').html();
	
	$('.btn-edit-name').hide();
	$('.user-name').hide();
	$('.edit-name-container').show();
	$('.edit-name').val(nickname);
	$('.edit-limit').html(nickname.length +'/10');

	$('.edit-submit').unbind('click');
	$('.edit-submit').click(function(e){
		Connection.socket.emit("edit customer name",{
			customer_id: target,
			manager_id: Connection.service_id,
			nickname: $('.edit-name').val()
		});
		$('.user-name').html($('.edit-name').val());
		$('.edit-cancel').trigger('click');
	});
}

// function edit_normal_trick(id, event) {
// 	//var element = null;
// 	if($('.txt').html() == "多人訊息"){
// 		if($('.dialog > div > #'+id).attr('type') == 'text'){
// 			var target = id.split('-');
// 			$('.dialog > div > #'+id).attr('onclick','select_trick(event)').attr('type','button');
// 			event.srcElement.value = "編輯";
// 			Connection.normal_talk_trick[target[2]] = $('.dialog > div > #'+id).val();
// 			Connection.update_talk_tricks('Normal', Connection.normal_talk_trick);
			
// 		}else{
// 			$('.dialog > div > #'+id).attr('onclick','').attr('type','text');
// 			event.srcElement.value = "確認";
// 		}

// 	}else{
// 		if($('#'+id).attr('type') == 'text'){
// 			var target = id.split('-');
// 			$('#'+id).attr('onclick','select_trick(event)').attr('type','button');
// 			event.srcElement.value = "編輯";
// 			Connection.normal_talk_trick[target[2]] = $('#'+id).val();
// 			Connection.update_talk_tricks('Normal', Connection.normal_talk_trick);
	
// 		}else{
// 			$('#'+id).attr('onclick','').attr('type','text');
// 			event.srcElement.value = "確認";
// 		}
// 	}
// }

function call_customer(){
	var phone = Connection.client_info.PHONE;
	var name = Connection.client_info.detail.NICKNAME || Connection.client_info.name;
	if(phone=="NULL" || phone == null || phone == ""){
		warningMsg("撥打電話", name+" 沒有登記電話",[{
			text: "確定", 
			click: function() { 
				$(this).dialog("close");
				$('.all').hide();
			}
		}]);
	}
	else{
		warningMsg("撥打電話","確認要打電話給 " + name + " 嗎?",[{
			text: "確定", 
			click: function() { 
				location.href= "tel:" + phone;
				$(this).dialog("close");
				$('.all').hide();
			}
		},{
			text: "取消", 
			click: function() { 
				$(this).dialog("close");
				$('.all').hide();
			}
		}]);
	}
}