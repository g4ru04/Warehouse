﻿//Only for cs_customer

$( function() {
	
	set_dialog_trigger();
	
	$(".btn-search").click(function(){
		send_text_msg();
	});
	$("textarea.input.msg").keydown(function (e) {
		if (e.which == 13) {
			e.preventDefault();
			send_text_msg();
		}
	});
	$('textarea').on('change paste keyup', function(e){
		this.style.height = "";
		this.style.height = this.scrollHeight + "px";
	})

	$("#btn-camera").click(function(){
		$("#take_picture").trigger("click");
	});
	$("#btn-photo").click(function(){
		$("#upload_picture").trigger("click");
	});
	
	//三秒後自動關閉個資宣告
	$("#dialog-safty").dialog("open");
	setTimeout(function(){ 
		if($('div[aria-describedby="dialog-safty"]').is(":visible")){
			$("#dialog-safty").dialog("close");
			$(".left-top").hide();	
		}
	}, 3000);

	$(".left-top").show();	

	$('img#safty').click(function(){
		$("#dialog-safty").dialog("open");
		$("#dialog-hint").dialog("close");
		$(".left-top").show();
	})

	$('img#hint').click(function(){
		$("#dialog-hint").dialog("open");
		$("#dialog-safty").dialog("close");
		$(".left-top").show();
	})

	//服務小幫手開啟
	$('#hint-service').click(function(){
		$("#dialog-hint-service").dialog("open");
		$("#dialog-hint").dialog('close');
		$(".left-top").hide();
		$(".all").show();
	})
	//服務小幫手按鈕關閉功能
	$("#btnclose").click(function(){
		$("#dialog-hint-service").dialog("close");
		$(".all").hide();
	});
	//評分開啟
	$('#hint-score').click(function(){
		$("#dialog-score").dialog("open");
		$("#dialog-hint").dialog('close');
		$(".left-top").hide();
		$(".all").show();
	})
	$('.detail-page-back').click(function(e){
		$('#detail-page').dialog('close');
	});

	//星星點亮功能
	$('#starfield img').click(function(){

		var index = ($(this).index());

		$('#starfield img:lt(' + (index + 1) + ')').attr("src", "/images/star.png");

		$('#starfield img:gt(' + index + ')').attr("src", "/images/star_gray.png");
	})


	$('button span.ui-button-icon.ui-icon.ui-icon-closethick').click(function(){
		$('.ui-widget-overlay.ui-front').hide();
	})

	$('#btn-phone').click(function(){
		var phone = Connection.service_info.PHONE;
		if (phone == "NULL" || phone == null || phone == "") {
			warningMsg('錯誤!', "專員沒有登記電話")
		}
		else {
			$(".all").show();
			warningMsg("撥打電話", "確認要打電話" + phone + "給" + Connection.service_info.name + "專員嗎?", [{
				text: "確定",
				click: function () {
					location.href = "tel:" + phone;
					$(this).dialog("close");
					$('.ui-widget-overlay.ui-front').hide();
				}
			}, {
				text: "取消",
				click: function () {
					$(this).dialog("close");
					$('.ui-widget-overlay.ui-front').hide();
				}
			}]);
		}
	})
});
function send_score(){
	var rate = $('img[src="/images/star.png"]').length,
		advise = $('.custom-advise').val();
	
	console.log("送出建議",rate,advise);

	//關閉+清空
	$('button span.ui-button-icon.ui-icon.ui-icon-closethick').trigger('click');
	$('img[src="/images/star.png"]').attr("src", "/images/star_gray.png");
	$('.custom-advise').val("");
}

function maintain_log_init() {
	$('#btn-fix').click(function(){
		$('#password').val('');
		$("#dialog-login").dialog("open");
		$('.all').show();
	})

	// $("#maintain-return").click(function(){
	// 	$('#maintain-page').dialog('show');
	// });
	$("#detail-return").click(function(){
		$('#detail-page').dialog('open')
	});
}

function moredetail(DLRCD, BRNHCD, WORKNO, RTPTDT, RTPTML, TOTAMT) {
	call_hotai_api("LINELCS03_Q02", {
		"DLRCD": DLRCD,
		"BRNHCD": BRNHCD,
		"WORKNO": WORKNO
	}, function (data) {
		$('#detail-no').html("工單編號: " + WORKNO);
		$('#detail-date').html("入廠日期: " + RTPTDT);
		$('#detail-kms').html("入廠里程: " + RTPTML);
		$('#detail-amt').html("發票金額:  " + TOTAMT);

		var list = '<div class="table-tr">'+
					'	<div class="table-th left">零件名稱</div>'+
					'	<div id="car-no" class="table-td right">數量</div>'+
					'</div>';
		if(data.PARTSDATA.length==0){
			list += '<div class="table-tr">'+
					'	<div class="table-td left">無更換零件</div>'+
					'	<div id="car-no" class="table-td right">-</div>'+
					'</div>';
		}else{
			list = data.PARTSDATA.map(function (item) {
				return '<div class="table-tr">'+
						'	<div class="table-td left">' + item.PTCHNM + '</div>'+
						'	<div id="car-no" class="table-td right">' + item.PCNT + '</div>'+
						'</div>';
			}).join('');
		}
		$('#maintain_details').html(list);
		$('#detail-page').show();
	});
}

function do_login() {
	call_hotai_api("LINE001_Q01", {
		"LICSNO": Connection.client_info.vehicle_number,
		"ENCYID": Connection.client_id,
		"HALFCUSTID": $("#password").val()
	}, function (data) {
		if ("Y" == data.PASSFLAG) {
			call_hotai_api("LINELCS03_Q01", {
				"ENCYID": Connection.client_id
			}, function (data) {
				$("#dialog").dialog("close");
				
				var dts = data.ISINFO;
				if(dts) dts = dts[0];
				$('#car-no').html(Connection.client_info.vehicle_number);
				$('#fendat').html(dts.FENDAT || '-');
				$('#uendat').html(dts.UENDAT || '-');

				var maintainLogs = data.LSFXINFO;
				var list = '<div class="table-tr">'+
							'	<div class="table-th left">日期</div>'+
							'	<div class="table-th right">里程數(km)</div>'+
							'</div>';
				if(maintainLogs.length == 0){
					list += '<div class="table-tr">'+
							'	<div class="table-td left">無記錄</div>'+
							'	<div class="table-td right">-</div>'+
							'</div>';
				}else{
					list += maintainLogs.map(function (item) {
						return '<div class="table-tr" onclick="javascript:moredetail(\'' +
								item.DLRCD + '\',\'' + item.BRNHCD + '\',\'' + item.WORKNO + '\',\'' +
								item.RTPTDT + '\',\'' + item.RTPTML + '\',\'' + item.TOTAMT + '\')">'+
								'	<div class="table-td left">'+ item.RTPTDT +'</div>'+
								'	<div class="table-td right">'+
										item.RTPTML +
								'		<img src="/images/dark-go.png">'+
								'	</div>'+
								'</div>';
					}).join('');
				}

				$('#fix-log').html(list);
				$('#maintain-page').dialog('open');
				$('.all').show();
			});
		} else {
			warningMsg("錯誤!", "密碼錯誤" + (data.rtnMsg ? "," + data.rtnMsg : ""))
		}
	});
	$("#dialog-login").dialog('close');
	$('.ui-widget-overlay.ui-front').hide();
}