﻿

/* 關閉自定義 errorhandlerlog 請解開右邊 註解 → *
window.onerror = function (msg, url, line, col, error) {
 setTimeout(function () {
  $.ajax({
   type: "POST",
   //url: "https://nodered-api-lexus-test01.mybluemix.net/error_log_temp",
   url: "/logger",
   data: {
    platform: "PageError",
    message: JSON.stringify({
		message:msg,
		url:url,
		line:line,
		col:col,
		})
   }
  });
 }, 2000);
}

$(function () {
 $.ajaxSetup({
  error: function (jqXHR, exception, errorThrown) {
   if (jqXHR.status == 0) {
    return; //零只是因為還沒丟就跳頁了
   }
   var log_msg = 'Ajax.ERROR\n'
     + '\tsend:[' + JSON.stringify(this.data)
     + ']\n\tto:[' + this.url + ']'
     + '\n\tGet:[' + jqXHR.status + "-" + jqXHR.statusText + ']';
   setTimeout(function () {
    $.ajax({
     type: "POST",
     //url: "https://nodered-api-lexus-test01.mybluemix.net/error_log_temp",
	 url: "/logger",
     data: {
      platform: "PageError",
      message: log_msg
     }
    });
   }, 2000);
  }
 });
});
/* 關閉自定義 errorhandlerlog 請解開右上 註解  */
/*修改log*/
//sys_console=console.log;
/*  for 手機log *
console.log = function(msg1,msg2,msg3,msg4){
		send_console(msg1,msg2,msg3,msg4);
}
/*  for 手機log */
function send_console(msg1,msg2,msg3,msg4){
		//sys_console(msg1);
		//return ;
		let msg = JSON.stringify(msg1);
		msg+=msg2?JSON.stringify(msg2):"";
		msg+=msg3?JSON.stringify(msg3):"";
		msg+=msg4?JSON.stringify(msg4):"";
		sys_console(msg);
		 $.ajax({
		   type: "POST",
		   //url: "https://nodered-api-lexus-test01.mybluemix.net/error_log_temp",
		   url: "/logger",
		   data: {
			platform: "LOG",
			message: "########"+msg+"########"
		   }
		  });
}
function call_hotai_api(api_code,data,callback){
	let api_dict = {
		"LINE001_Q01":"安全性驗證(Cust功能)",
		"LINE006_Q00":"取得業代專員資料(LINE轉一對一)",
		"LINE006_Q01":"取得業代專員資料(Serv登入呼叫-2)",
		"LINELCS01_Q01":"車主資料查詢(Serv功能)",
		"LINELCS02_D01":"回廠預約取消(Serv功能-預約-5)",
		"LINELCS02_I01":"回廠預約(Serv功能-預約-1)",
		"LINELCS02_Q01":"服務據點查詢(Serv功能-預約-2)",
		"LINELCS02_Q02":"服務據點查詢(Serv功能-預約-3)",
		"LINELCS02_Q03":"預約明細資料回傳(Serv功能-預約-4)",
		"LINELCS03_Q01":"車主資料(Cust功能)",
		"LINELCS03_Q02":"車主維修零件明細(Cust功能)",
		"SendMessage":"通知專員(Sys功能)",
		"USER_LOGIN":"專員登入(Serv登入呼叫-1)"
	}
	
	
	console.log(api_code,api_dict[api_code],data);
	//console.log("call_hotai_api('"+api_code+"',"+JSON.stringify(data)+")");
	$('.all').show()
	var params = JSON.stringify({
		api: api_code,
		data:data,
		detail:true
	});
	var today = new Date();
	
	var apilog = {
		url: "HT_API_URL/" + api_code,
		start: today.toLocaleDateString('zh-tw') + ' ' + today.toLocaleTimeString('zh-tw'),
		end: "",
		success: "",
		params: params,
		data: ""
	};

	$.ajax({
		type : "POST",
		url : "/api",
		cache : false,
		contentType: 'application/json; charset=UTF-8',
		data : params,
		success: function(d) {
			console.log(api_code,d);
			
			today = new Date();
			apilog.end = today.toLocaleDateString() + ' ' + today.toTimeString().split(' ')[0]
			apilog.success = "Y";
			apilog.data = d;

			if(api_code =="USER_LOGIN"){
				setTimeout(function(e){
					if(callback){
						callback(d);
					}
				},200);
			}else if(d.isSuccess){
				setTimeout(function(e){
					if(callback){
						callback(d.result);
					}
				},200);
			}else{
				console.log(d);
				warningMsg("錯誤", d.result.rtnMsg || 'API取得失敗');
			}
		},error: function (jqXHR, textStatus, errorThrown) {
			warningMsg('API使用異常:', api_code+","+textStatus)
			console.log(jqXHR,textStatus,errorThrown);
			
			today = new Date();
			apilog.end = today.toLocaleDateString('zh-tw') + ' ' + today.toLocaleTimeString('zh-tw');
			apilog.success = "N";
			apilog.data = textStatus;
		},complete: function() {
			// console.log(apilog.data.length,apilog.data)
			try{
				Connection.api_log(apilog);
			}catch(e){
				//console.log('send api log')
				io(socket_server_ip).emit("api log", apilog).close();
			}
        }
	});
	
}

function common_conn_setting(conn){
	
	//conn.client_id = 
	//		conn.client_id || (getUrlParameter("c")?b64DecodeUnicode(getUrlParameter("c")):UUID());
	conn.service_id = 
		conn.service_id || (getUrlParameter("s")?b64DecodeUnicode(getUrlParameter("s")):UUID());
	conn.conn = 
		conn.conn || (false) ;
	conn.talks = 
		conn.talk || ([]);
	conn.talks_history_cursor = 
		conn.talks_history_cursor || (0);
	
	conn.reiceive_msg =
		conn.reiceive_msg || function (message){
				$("#console").append(produce_dialog_element(message));
				$("#console").scrollTop($('#console')[0].scrollHeight);
			}
	
	conn.is_connect = function(){
		return conn.socket.connected;
	}
	conn.socket.on('disconnect', function () {
		my_console('已斷線');
	});
	
	conn.socket.on('message', function (data) {
		console.log("socket_event: message",data);
		conn.talks_history_cursor += 1;
		conn.talks.push(data);
		conn.reiceive_msg(data);
	});
	
	conn.socket.on('get history', function (data) {
		
		conn.talks_history_cursor += data.data.length;
		conn.talks = conn.talks.concat(data.data);
		//此為補上歷史資料
		data.data.sort(function(a,b){
			return b.time - a.time;
		});
		
		smoothly_set_history(JSON.parse(JSON.stringify(data.data)));

	});
	
	conn.send_text = function(message){
		//let service_icon = "https://customer-service-xiang.herokuapp.com/images/Lexus_icon.png";
		//let client_icon = "/images/avatar.png";
		if(conn.client_id){
			conn.socket.emit("message", {
				"type": conn.end_point,
				"from": {
					"id": (conn.end_point=="service"?conn.service_id:conn.client_id),
					"name": (conn.end_point=="service"?conn.service_info.name:conn.client_info.name),
					"avator": (conn.end_point=="service"?conn.service_info.avator:conn.client_info.avator)
				},
				"to": {
					"id": (conn.end_point=="service"?conn.client_id:conn.service_id),
					"name": (conn.end_point=="service"?conn.client_info.name:conn.service_info.name),
					"avator": (conn.end_point=="service"?conn.client_info.avator:conn.service_info.avator)
				},
				"time": Date.now(),
				"message": {
					"type": "text",
					"text": message
				},
				"push":false
			});
		}else{
			warningMsg('錯誤!', '無對象')
		}
	}
	
	conn.send_image = function(url){
		//let service_icon = "https://customer-service-xiang.herokuapp.com/images/Lexus_icon.png";
		//let client_icon = "/images/avatar.png";
		var item = {
			"type": conn.end_point,
			"from": {
				"id": (conn.end_point=="service"?conn.service_id:conn.client_id),
				"name": (conn.end_point=="service"?conn.service_info.name:conn.client_info.name),
				"avator": (conn.end_point=="service"?conn.service_info.avator:conn.client_info.avator)
			},
			"to": {
				"id": (conn.end_point=="service"?conn.client_id:conn.service_id),
				"name": (conn.end_point=="service"?conn.client_info.name:conn.service_info.name),
				"avator": (conn.end_point=="service"?conn.client_info.avator:conn.service_info.avator)
			},
			"time": Date.now(),
			"message": {
				"type": "image",
				"url": url
			},
			"push":false
		}
		console.log('img item:',item)
		conn.socket.emit("message", item);
	}
	
	conn.get_history = function(num){
		num = num?num:10;
		if(!conn.getting_history){
			conn.getting_history = true;
			$("#console .loading_div").addClass("active");
			conn.socket.emit("get history",{
				"skip": conn.talks_history_cursor,
				"limit":num
			});
		}
	}

	//melvin
	conn.group_send = function(msg_obj){
		msg_obj.push = true;
		//console.log('msg_obj',msg_obj)
		conn.socket.emit("message", msg_obj);
	}
	conn.api_log = function(log){
		Connection.socket.emit("api log", log);
	}
}
// function IosPreventDefault(){
	
// }
function emotion_setting(){
	let emotion_icon_list=['1f60a.png','1f60c.png','1f60d.png','1f60f.png','1f61a.png',
							'1f61c.png','1f61d.png','1f61e.png','1f62a.png','1f62d.png']
	let emotion_str = emotion_icon_list.map(function(icon_name){
		return '<a href="#" class="emotion_icon" icon_name="'+icon_name+'">'
			+'<img src="/images/'+icon_name+'">'
		+'</a>';
	})
	$("#emoticon_container").delegate( ".emotion_icon", "click", function() {
		Connection.send_image(location.origin+'/images/'+$(this).attr("icon_name"));
		$("#emoticon_container").toggleClass("emotionIconOn"); 
	});

	$("#emoticon_container").html(emotion_str);
	
	$(".btn-laugh").click(function(){
		$("#emoticon_container").toggleClass("emotionIconOn"); 
	});
}

function produce_dialog_element(message) {
	// console.log('message',message)

	if(message.from==null || message.message==null){
		return JSON.stringify(message,null,"    ")
				.replace(/    /g,"&nbsp;&nbsp;&nbsp;")
				.replace(/\n/g,"<br>")+"<br>";
	}
	var style = "";
	if(message.type=="service" && message.from.name == "LEXUS"){
		style = " style='width: 40px;'";
	}
		
	let the_time = new Date(message.time);
	
	let message_str = "";
	if(message.message.type=="text"){
		message_str = message.message.text
						.replace(/\n/g,"<br>") ;
		message_str = '		<div class="dialogPop">'
					+'			<p class="dialogPop__comment">'+message_str+'</p>'
					+'		</div>'
		
	}else if(message.message.type=="image"){
		message.message.url = message.message.url; //.replace('http://192.168.25.105:8080','http://aa961c4f.ngrok.io')	
		message_str = "<a target='_blank' data-lightbox='img1' href='"+message.message.url+"'>"
						+"<img src='"+message.message.url+"' class='dialog__img' />"
						+"</a>";
		
	}
	
	// message_str += "<br>";
	
	// if(message.intents && Connection.end_point=="service"){
	// 	message.intents = message.intents.filter(function(item){
	// 		return item.confidence>0.3;
	// 	});
	// 	if(message.intents.length!=0){
	// 		message_str += "【"
	// 			+message.intents.map(function(item){
	// 				return item.intent+"("+
	// 					new Number(item.confidence).toFixed(3)
	// 				+") ";
	// 			}).join(",")
	// 		+"】";
	// 	}else{
	// 		message_str += "【無明確意圖】";
	// 	}
	// }
	// if(message.recognitionResult && Connection.end_point=="service"){
	// 	message_str += "【"+message.recognitionResult+"】";
	// }
	/*
	let from_info = {name:"SOMEONE",avator:"/images/avatar.png"};
	if(message.from.id == Connection.client_info.id){
		from_info = Connection.client_info;
	}
	if(message.from.id == Connection.service_info.id){
		from_info = Connection.service_info;
	}*/
	let nickname = "";
	if(Connection.conversation_list){
		Object.keys(Connection.conversation_list).forEach(function(item){
			if(item == Connection.client_id) 
			nickname = Connection.conversation_list[item].customer_nickname
		})
	}
	if(message.type == "client"){
		message.from.name = nickname==""?message.from.name:nickname;
	}
	let avator = "";
	if(Connection.end_point != message.type){
		avator = '<div class="dialog__profile">'
		+'	<div class="dialog__profileImage"><img src="'+message.from.avator+'"'+style+'></div>'
		// +'	<div class="dialog__profileName">'+message.from.name+'</div>'
		+'	</div>';
	}
	return '<div class="dialog dialog--'+message.type+' clearfix" timestamp="' + message.time + '">'
		+ 	avator
		+'	<div class="dialog__content" message_id="'+message.message_id+'" onclick=\'if(window.talk_tricks_setting_with_message_id)talk_tricks_setting_with_message_id("'+message.message_id+'")\'>'
		+       message_str
		+'		<div class="dialogTips">'
		+'			<div class="dialogTips__read"></div>'
		+'			<div class="dialogTips__time">'
		+				displayChatTime(the_time)
		+'			</div>'
		+'		</div>'
		+'	</div>'
		+'</div>';
}
function produce_dialog_seperate(msg){
	return '<div class="dialog clearfix">'+
			'	<div class="dialog-seperate" style="text-align: center;"><a>' + msg + '</a></div>'+
			'</div>';
}
function smoothly_set_history(data){
	if(data.length>0){
		setTimeout(function(){
			let item = data.shift();

			var date_str = "";
			var thistime = get_message_time(item.time);
			var nexttime = $('#console > .dialog[timestamp]').length>0 ? 
							$('#console > .dialog[timestamp]:first').attr('timestamp') : "";
			if(nexttime){
				nexttime = get_message_time(nexttime-0);
				if(thistime.fulldate != nexttime.fulldate){
					if(thistime.year != nexttime.year){
						date_str+=nexttime.year+'/';
					}
					date_str+=nexttime.date;
					$("#console .loading_div").after(produce_dialog_seperate(date_str));
				}
			}

			$("#console .loading_div").after(
				produce_dialog_element(item)
			);
			smoothly_set_history(data)
		},100);
	}else{
		Connection.getting_history = false;
		$("#console .loading_div").removeClass("active")
	}
}

function get_message_time(time){
	var d = moment(time);
	var weekday = ['周一','周二','周三','周四','周五','周六','周日'];
	return {
		fulldate: d.format('YYYY/MM/DD'),
		year: d.format('YYYY'),
		date: d.format('MM/DD'),
		time: d.format('hh:ss'),
		weekday: weekday[d.format('e')],
		timestamp: time
	}
}

function lexus_sys_talk(message){
	//https://lexus-cs.herokuapp.com/images/cs_icon.png
	$("#console").append(
		produce_dialog_element({
			"type":"service",
			"from":{
				"avator":"/images/Lexus_logo.png",
				"name":"LEXUS"
			},
			"message":{
				"type":"text",
				"text":message
			},
			"time":Date.now()
		})
	);
}

function my_console(message){
	// $("#console").append(produce_dialog_element(message));
	// $("#console").scrollTop($('#console')[0].scrollHeight);
}

//click or event 使用
function send_text_msg(){
	
	if(Connection&&$("textarea.input.msg").val().length>0){
		Connection.send_text($("textarea.input.msg").val());
		$("textarea.input.msg").val('');
		$("textarea.input.msg").trigger('change');
	}
	
}

//圖檔壓縮
$('input#upload_picture[type="file"]').on('change',function(e){
	console.log(1,e,this)
	uploadimage(this, 'upload_picture');
})
$('input#take_picture[type="file"]').on('change',function(e){
	console.log(2,e,this)
	uploadimage(this, 'take_picture');
})

function uploadimage(obj, source){
	var tt = 500; //壓縮後最大寬度

	// Ben
	let file_val = $('#'+source).val();
	let validExts = [".png",".jpg",".jpeg",".gif",".bmp"];
	let file_ext = file_val.substring(file_val.lastIndexOf('.'))
	if (validExts.indexOf(file_ext.toLowerCase()) < 0) {
		$('#'+source).val('');
		warningMsg('錯誤!', "只接受此類圖片檔案：" + validExts.join(", "))
		return ;
	}

	// var data = new FormData();
    // $.each($('#upload_picture')[0].files, function(i, file) {
    //     data.append('file-'+i, file);
	// });
	// console.log('pic:',data)

	//Cat 壓縮
	var _this = $(obj)[0], _file = _this.files[0], fileType = _file.type;

	var fileReader = new FileReader();
	fileReader.readAsDataURL(_file);
	fileReader.onload = function (event) {
		var result = event.target.result;   //返回的dataURL
		var image = new Image();
		image.src = result;
		image.onload = function () {  //创建一个image对象，给canvas绘制使用
			var cvs = document.createElement('canvas');   
			var ctx = cvs.getContext('2d')
			var scale = 1;
			
			if (this.width > tt || this.height > tt) {
				if (this.width > this.height) {
					scale = tt / this.width;
				} else {
					scale = tt / this.height;
				}
			}

			EXIF.getData(image, function(){
				EXIF.getAllTags(this);
				var orientation = EXIF.getTag(this, 'Orientation');       
				switch(orientation){
					case 1:
						//0°
						cvs.height = image.height * scale;
						cvs.width = image.width * scale;
						ctx.drawImage(image, 0, 0, cvs.width, cvs.height);
						break;
					case 6:
						//+90°
						cvs.width = image.height * scale;
						cvs.height = image.width * scale;
						ctx.rotate(90 * Math.PI / 180);
						ctx.drawImage(image, 0, -cvs.width, cvs.height, cvs.width);
						break;
					case 8:
						//-90°
						cvs.width = image.height * scale;
						cvs.height = image.width * scale;
						ctx.rotate(-90 * Math.PI / 180);
						ctx.drawImage(image, -cvs.width, 0, cvs.height, cvs.width);
						break;
					case 3:
						//180°
						cvs.height = image.height * scale;
						cvs.width = image.width * scale;
						ctx.rotate(Math.PI);
						ctx.drawImage(image, -cvs.width, -cvs.height, cvs.width, cvs.height);
						break;
					default:
						cvs.height = image.height * scale;
						cvs.width = image.width * scale;
						ctx.drawImage(image, 0, 0, cvs.width, cvs.height);
				};    
   
			})

			//计算等比缩小后图片宽高
			// cvs.width = this.width * scale;
			// cvs.height = this.height * scale;  ;
			// ctx.drawImage(this, 0, 0, cvs.width, cvs.height);
			var newImageData = cvs.toDataURL(fileType);   //重新生成图片，fileType为用户选择的图片类型
			var blob = dataURItoBlob(newImageData);
			var data = new FormData();
			data.append("canvasImage", blob);

			$.ajax({
				url: '/upload',
				type: 'POST',
				data: data,
				cache: false,
			    contentType: false,
			    processData: false,
			    method: 'POST',
				success: function(data){
					if(data.status=="success"){
						send_image_msg(data.url);
					}else{
						warningMsg('錯誤!', "檔案上傳失敗")
					}
				},
				error: function(xhr, status, error) {
					console.log(xhr);
					console.log(status);
					console.log(error);
				}
			});
		}
	}
}

//blob
function dataURItoBlob(dataURI) {
    // convert base64/URLEncoded data component to raw binary data held in a string
    var byteString;
    if (dataURI.split(',')[0].indexOf('base64') >= 0)
        byteString = atob(dataURI.split(',')[1]);
    else
        byteString = unescape(dataURI.split(',')[1]);

    // separate out the mime component
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

    // write the bytes of the string to a typed array
    var ia = new Uint8Array(byteString.length);
    for (var i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }

    return new Blob([ia], {type:mimeString});
}

//click or event 使用
function send_image_msg(url){
	
	if(Connection){
		Connection.send_image(url);
		$("input[type='file']").val('');
	}
	
}

function set_dialog_trigger(){
	//讀歷史紀錄trigger
	let element = document.getElementById("console");
	if(navigator.userAgent.indexOf("Firefox") !== -1){
		element.addEventListener("DOMMouseScroll",wheelHandler,false);
	}
	element.onmousewheel = wheelHandler;

	function wheelHandler(event){ 
		event = event || window.event; 
		var delta = event.wheelDelta || event.detail*-30;
		if(delta>0 && $("#console").scrollTop()==0){
			Connection.get_history();
		}
	}
	
	$("#console").on("touchstart", function(e) {
		// 判断默认行为是否可以被禁用
		if (e.cancelable) {
			// 判断默认行为是否已经被禁用
			if (!e.defaultPrevented) {
				//e.preventDefault();
			}
		}   
		startX = e.originalEvent.changedTouches[0].pageX,
		startY = e.originalEvent.changedTouches[0].pageY;
	});
	
	$("#console").on("touchmove", function(e){
		if (e.cancelable) {
			// 判断默认行为是否已经被禁用
			if (!e.defaultPrevented) {
				//e.preventDefault();
			}
		}               
		moveEndX = e.originalEvent.changedTouches[0].pageX,
		moveEndY = e.originalEvent.changedTouches[0].pageY,
		X = moveEndX - startX,
		Y = moveEndY - startY;
		if ( Y > 0 && $("#console").scrollTop()==0) {
			Connection.get_history();
		}
		
	});
	$("body *").on("touchstart", function(e) {
		startX = e.originalEvent.changedTouches[0].pageX,
		startY = e.originalEvent.changedTouches[0].pageY;
	});
	
	$("body *").on("touchmove", function(e){
		moveEndX = e.originalEvent.changedTouches[0].pageX,
		moveEndY = e.originalEvent.changedTouches[0].pageY,
		X = moveEndX - startX,
		Y = moveEndY - startY;
		if($(this).prop("scrollHeight")>$(this).height()){
			e.stopPropagation();
		}
		
		if(
			Y>0&& $(this).scrollTop()<=0 || 
			Y<0&& $(this).scrollTop()+ $(this).height()>=$(this).prop("scrollHeight")
		){
	 		e.preventDefault();
	 	}
	});

}

function warningMsg(title, msg, buttons) {
	$('.all').show()
	$("<div id='warning'/>").html(msg).dialog({
		title: title,
		draggable : false, resizable : false, autoOpen : true,
		height : "auto", width : "240", modal : true,
		buttons : buttons ? buttons:[{
			text: "確定", 
			click: function() { 
				$(this).dialog("close");
				$('.all').hide();
			}
		}]
	});
}

function displayChatTime(time){
	let the_time = moment(time);
	var today = moment(new Date());
	if(today.format('YYYYMMDD') == the_time.format('YYYYMMDD')){
		return the_time.format('hh:mm');
	}else{
		return the_time.format('MM/DD');
	}

	// return (Array(2).join("0") +the_time.getHours()).slice(-2) +":"+ (Array(2).join("0") +the_time.getMinutes()).slice(-2)
}

function getUrlParameter(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function b64EncodeUnicode(str) {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function(match, p1) {
        return String.fromCharCode('0x' + p1);
    }));
}

function b64DecodeUnicode(str) {
    return decodeURIComponent(Array.prototype.map.call(atob(str), function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
}

function UUID(){
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
	    var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
	    return v.toString(16);
	});
}

function post(path, params, method) {
	method = method || "post";
	var form = document.createElement("form");
	form.setAttribute("method", method);
	form.setAttribute("action", path);

	for(var key in params) {
		if(params.hasOwnProperty(key)) {
			var hiddenField = document.createElement("input");
			hiddenField.setAttribute("type", "hidden");
			hiddenField.setAttribute("name", key);
			hiddenField.setAttribute("value", params[key]);

			form.appendChild(hiddenField);
		}
	}

	document.body.appendChild(form);
	form.submit();
}
function Browser(){
	return navigator.userAgent;
}
function setLightbox(){
	//lightbox設定
	lightbox.option({
		'resizeDuration': 100,
		'fitImagesInViewport':true,
		'fadeDuration' : 100,
		'disableScrolling' : true,
		'maxWidth':182,
	 })
}
function reset_console_height(){
 
	let at_bottom=true;
	if($("#console").scrollTop()+$("#console").height()<$("#console")[0].scrollHeight-10){
		at_bottom=false
	}
	$("#console").height("calc( 100% - "+$(".control-bar").height()+"px - "+$(".header_content").height()+"px )");
	if(at_bottom){
		$("#console").scrollTop($("#console")[0].scrollHeight);
	}
}