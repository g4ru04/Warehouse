module.exports = {
	"develop": true,
	"socket_server": {
		"ip": "http://40.74.77.84:1880/"
		// "ip": "http://192.168.43.217:8082/"
	},
	"hoital_api":{
		"develop": "https://htsr.hotaimotor.com.tw/LINEAPI_TEST/Service.asmx/",
		"product": "https://htsr.hotaimotor.com.tw/LINEAPI/Service.asmx/"
	},
	"line": {
		"sendmessage": "https://htsr.hotaimotor.com.tw/LINENOTIFYAPI_TEST/LineNotify/SendMessage/"
	},
	"express_server": {
		"ip": "http://40.74.77.84:8080"
		// "ip":"http://192.168.43.217:8080"
	}
}