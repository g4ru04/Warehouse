﻿var express = require('express');
var router = express.Router();
var common = require('../service/common');
var call_api = require('../service/ht_api.js');
var sp = require('../service/sp');
const logger = require('../service/logger') || console;

// const {google} = require('googleapis');

const settings = require('../configs.js');

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.post('/api', async function(req, res, next) {
	logger.log("CallAPI",req.body);
	let data = await call_api.HT_Api(req.body);
	//logger.log("CallAPIRet",data);
	res.send(data);
});
router.post('/logger', function(req, res){
	logger.log("logger",req.body);
	res.send("ok");
});

router.get('/cust.do', function(req, res, next) {
	res.send(`<html>
		<head>
			<title>頁面讀取中</title>
			<script src="/javascripts/common.js"></script>
		</head>
		<body>
			<script>
				post('/cust.do', {c: getUrlParameter('c'),s: getUrlParameter('s')});
			</script>
		</body>
	</html>`)
});

router.post('/cust.do', function(req, res, next) {
  console.log(req.body);
  logger.log("AccessCust",req.body);
  res.render('cs_customer',{
	  socket_server_ip: settings.socket_server.ip,
	  c: req.body.c,
	  s: req.body.s
  });
});

router.get('/serv.do', function(req, res, next) {
	logger.log("AccessServ",req.body);
	res.render('cs_manager',{
		socket_server_ip:settings.socket_server.ip,
		express_server_ip:settings.express_server.ip 
	});
});

router.post('/upload_image', function(req, res){
	sp.upload_image(req, res);
});

router.get('/api/json/sl', common.getSl);
router.get('/api/json/dl', common.getDl);
router.get('/api/json/tl', common.getTl);

module.exports = router;

function rev(str) {
    return str.split("").reverse().join("");
}

function de64(str){
	return Buffer.from(str, 'base64').toString('utf-8');
}
