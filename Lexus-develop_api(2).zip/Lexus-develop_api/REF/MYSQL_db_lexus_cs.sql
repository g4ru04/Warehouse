-- --------------------------------------------------------
-- 主機:                           127.0.0.1
-- 伺服器版本:                        5.7.16-log - MySQL Community Server (GPL)
-- 伺服器操作系統:                      Win64
-- HeidiSQL 版本:                  9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- 傾印 db_lexus_cs 的資料庫結構
CREATE DATABASE IF NOT EXISTS `db_lexus_cs` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `db_lexus_cs`;

-- 傾印  程序 db_lexus_cs.sp_api_log 結構
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_api_log`(
	IN `p_url` VARCHAR(200),
	IN `p_start` VARCHAR(50),
	IN `p_end` VARCHAR(50),
	IN `p_success` VARCHAR(20),
	IN `p_params` VARCHAR(2000),
	IN `p_data` VARCHAR(2000)






)
BEGIN

	INSERT INTO tb_call_api_log (`url`, `start`, `end`, `success`, `params`, `data`) 
	VALUES (p_url, p_start, p_end, p_success, p_params, p_data);

END//
DELIMITER ;

-- 傾印  程序 db_lexus_cs.sp_bind_client 結構
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_bind_client`(
	IN `p_manager_id` VARCHAR(50),
	IN `p_customer_id` VARCHAR(50),
	IN `p_customer_name` VARCHAR(20),
	IN `p_vehicle_type` VARCHAR(20),
	IN `p_vehicle_number` VARCHAR(20),
	IN `p_avator` VARCHAR(500),
	IN `p_telphone` VARCHAR(20),
	IN `p_fend_date` VARCHAR(20),
	IN `p_uend_date` VARCHAR(20),
	IN `p_birth_date` VARCHAR(20),
	IN `p_f_flag` VARCHAR(10),
	IN `p_u_flag` VARCHAR(10),
	IN `p_birth_flag` VARCHAR(10),
	IN `p_personal_data` VARCHAR(2000),
	IN `p_notify_data` VARCHAR(200)





)
BEGIN
	/* 20181022 By Ben */
	/* call sp_bind_client("SE0001","C0003","王二明",'CT200H', 'ABZ-1234', 'https://customer-service-xiang.herokuapp.com/images/avatar.png', '0919863010', '{"討厭的維修時間":"平日上班"}'); */
	DECLARE p_conversation_title varchar(60);
	DECLARE p_conversation_avator varchar(500);
	
	IF NOT EXISTS (
		SELECT customer_id FROM tb_customer WHERE ht_id = p_customer_id
	)THEN
		INSERT INTO tb_customer
		(`customer_id`, `ht_id`, `name`, `vehicle_type`, `vehicle_number`, `avator`, `telphone`, `fend_date`, `uend_date`, `birth_date`, `fend_need_notify`, `uend_need_notify`, `birth_need_notify`, `personal_data`, `personal_data_time`, `memo`) 
		VALUES (UUID(), p_customer_id, p_customer_name, p_vehicle_type, p_vehicle_number, p_avator, p_telphone, p_fend_date, p_uend_date, p_birth_date, p_f_flag, p_u_flag, p_birth_flag, IFNULL(p_personal_data,"{}"), NOW(), NULL);
	ELSE
		UPDATE tb_customer SET 
			avator = IFNULL(p_avator, avator),
			telphone = IFNULL(p_telphone, telphone),
			fend_date = IFNULL(p_fend_date, fend_date), 
			uend_date = IFNULL(p_uend_date, uend_date),
			birth_date = IFNULL(p_birth_date, birth_date),
			fend_need_notify = IFNULL(p_f_flag, fend_need_notify), 
			uend_need_notify = IFNULL(p_u_flag, uend_need_notify), 
			birth_need_notify = IFNULL(p_birth_flag, birth_need_notify)
		WHERE ht_id = p_customer_id;
	END IF;

	IF NOT EXISTS (
		SELECT responsibility_id FROM tb_responsibility WHERE manager_id = p_manager_id AND customer_id = p_customer_id
	)THEN
		SET p_conversation_title = (
				SELECT CONCAT(vehicle_type," | ",vehicle_number) 
				FROM tb_customer 
				WHERE ht_id = p_customer_id limit 0,1
			);

		SET p_conversation_avator = (
				SELECT avator 
				FROM tb_customer 
				WHERE ht_id = p_customer_id limit 0,1
			);
		#SET p_conversation_title = IFNULL(p_conversation_title, CONCAT("未知的使用者: ",p_customer_id));
		#SET p_conversation_avator = IFNULL(p_conversation_avator, "https://customer-service-xiang.herokuapp.com/images/avatar.png");
		INSERT INTO tb_responsibility 
		(`responsibility_id`, `manager_id`, `customer_id`, `conversation_title`, `customer_nickname`, `avator`, `last_talk_time`, `last_message`, `manager_unread`, `customer_unread`,`notify_data`)
		VALUES
		(UUID(), p_manager_id, p_customer_id, p_conversation_title, p_customer_name, p_conversation_avator,  NOW(), '', 0, 0, IFNULL(p_notify_data,"{}"));
	ELSE 
		UPDATE tb_responsibility SET 
			conversation_title = CONCAT(p_vehicle_type," | ", p_vehicle_number), 
			#customer_nickname = p_customer_name
			avator = p_avator,
			notify_data = IFNULL(p_notify_data,notify_data)
		WHERE manager_id = p_manager_id AND customer_id = p_customer_id;
	END IF;
	
END//
DELIMITER ;

-- 傾印  程序 db_lexus_cs.sp_edit_manager 結構
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_edit_manager`(
	IN `p_manager_id` VARCHAR(50),
	IN `p_compid` VARCHAR(50),
	IN `p_manager_name` VARCHAR(50),
	IN `p_telphone` VARCHAR(50)

)
BEGIN

	/* CALL sp_edit_manager('AA81344','AA','**賢','0225081288');  */
	
	IF EXISTS (
		SELECT manager_id FROM tb_manager WHERE ht_id = p_manager_id 
	)THEN
		UPDATE tb_manager SET 
			manager_name = IFNULL(p_manager_name, manager_name),
			telphone = IFNULL(p_telphone, telphone)
		WHERE ht_id = p_manager_id;
	ELSE 
		INSERT INTO tb_manager (`manager_id`, `ht_id`, `compid`, `manager_name`, `telphone`, `personal_data_time`) 
		VALUES (UUID(), p_manager_id, p_compid, p_manager_name, p_telphone, NOW());
	END IF;
	
END//
DELIMITER ;

-- 傾印  程序 db_lexus_cs.sp_select_conversation_info 結構
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_select_conversation_info`(
	IN `p_manager_id` VARCHAR(50),
	IN `p_customer_id` VARCHAR(50)








)
    NO SQL
BEGIN
	/* 20181022 By Ben */
	/* call sp_select_conversation_info("SE0001","C0003"); */
	DECLARE p_manager_json_data varchar(3000);
	DECLARE p_customer_json_data varchar(3000);
	DECLARE p_unread varchar(30);
	
	SET p_manager_json_data = (SELECT 
		CONCAT('{"end_point":"service","id":"',ht_id,'","name":"',manager_name,'","type":"',IFNULL(manager_type,""),'","avator":"',IFNULL(avator,""),'","PHONE":"',IFNULL(telphone,""),'"}')
	FROM tb_manager where ht_id = p_manager_id LIMIT 0,1);
	
	SET p_customer_json_data = (SELECT 
	
		CONCAT ('{"end_point":"client","id":"',ht_id,'","name":"',name,'","vehicle_type":"',vehicle_type,'","vehicle_number":"',vehicle_number,'","avator":"',avator,'","PHONE":"',telphone,'"}')
		/*json_merge(
			json_object(
				"end_point","client",
				"id",ht_id,
				"name",name,
				"vehicle_type",vehicle_type,
				"vehicle_number",vehicle_number,
				"avator",avator,
				"PHONE",telphone,
				"personal_data_time",personal_data_time
			),personal_data
		)*/
	FROM tb_customer where ht_id = p_customer_id LIMIT 0,1); 
	
	SET p_unread = (SELECT customer_unread FROM tb_responsibility where customer_id = p_customer_id LIMIT 0,1);
	SET p_manager_json_data = IFNULL(p_manager_json_data,"{}");
	SET p_customer_json_data = IFNULL(p_customer_json_data,"{}");
	
	SELECT p_manager_json_data manager_data, p_customer_json_data customer_data, p_unread unread;
	#SELECT json_array(p_manager_json_data,p_customer_json_data) conversation_info ;
	
END//
DELIMITER ;

-- 傾印  程序 db_lexus_cs.sp_select_manager_list 結構
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_select_manager_list`(
	IN `p_manager_id` VARCHAR(50)



,
	IN `p_customer_id` VARCHAR(50)
)
BEGIN
	/* 20181022 By Ben */
	/* call sp_select_manager_list("SE0001"); */
	
	/*SELECT customer_id, conversation_title, customer_nickname, avator, last_talk_time, last_message, manager_unread, notify_data
	from tb_responsibility WHERE manager_id = p_manager_id ORDER BY last_talk_time DESC;

	/* 20181112 By Cat */

	IF EXISTS (
		SELECT customer_id FROM tb_responsibility WHERE manager_id = p_manager_id AND customer_id = p_customer_id
	)THEN
		SELECT tb_responsibility.customer_id, tb_responsibility.conversation_title, tb_responsibility.customer_nickname, tb_responsibility.avator, tb_responsibility.last_talk_time, tb_responsibility.last_message, tb_responsibility.manager_unread, tb_responsibility.notify_data
			,tb_customer.fend_need_notify, tb_customer.uend_need_notify, tb_customer.birth_need_notify, tb_customer.fend_notify, tb_customer.uend_notify, tb_customer.birth_notify
		FROM tb_responsibility RIGHT OUTER JOIN tb_customer ON tb_responsibility.customer_id=tb_customer.ht_id WHERE tb_responsibility.manager_id = p_manager_id AND tb_responsibility.customer_id = p_customer_id LIMIT 0,1;
	ELSE 
		SELECT tb_responsibility.customer_id, tb_responsibility.conversation_title, tb_responsibility.customer_nickname, tb_responsibility.avator, tb_responsibility.last_talk_time, tb_responsibility.last_message, tb_responsibility.manager_unread, tb_responsibility.notify_data
			,tb_customer.fend_need_notify, tb_customer.uend_need_notify, tb_customer.birth_need_notify, tb_customer.fend_notify, tb_customer.uend_notify, tb_customer.birth_notify
		FROM tb_responsibility RIGHT OUTER JOIN tb_customer ON tb_responsibility.customer_id=tb_customer.ht_id WHERE tb_responsibility.manager_id = p_manager_id;

	END IF;
	
END//
DELIMITER ;

-- 傾印  程序 db_lexus_cs.sp_select_talk_history 結構
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_select_talk_history`(
	IN `p_endpoint` VARCHAR(50),
	IN `p_manager_id` VARCHAR(50),
	IN `p_customer_id` VARCHAR(50),
	IN `p_skip` INT,
	IN `p_limit` INT





)
BEGIN
	/* 20181024 By Ben */
	/* call sp_select_talk_history("client","SE0001","C0003",null,null); */
	DECLARE p_skip_exec int default 0;
	DECLARE p_limit_exec int default 1;
	
	IF p_skip IS NOT NULL THEN	
		SET p_skip_exec = p_skip;
	END IF;
	IF p_limit IS NOT NULL THEN	
		SET p_limit_exec = p_limit;
	END IF;
	
	IF p_endpoint = "service" AND p_skip IS NULL AND p_limit IS NULL THEN
		SET p_limit_exec = (SELECT manager_unread FROM tb_responsibility WHERE manager_id = p_manager_id AND customer_id = p_customer_id LIMIT 0,1)+1;
		SET p_limit_exec = IF(p_limit_exec>1 OR p_limit_exec=0,p_limit_exec,1);
	END IF;
	
	IF p_endpoint = "service" THEN
		UPDATE tb_responsibility SET manager_unread = '0' WHERE manager_id = p_manager_id AND customer_id = p_customer_id;
	END IF;
	
	SELECT * 
	#message_type, content, avator, last_talk_time, last_message, unread, note
	FROM tb_message 
	LEFT JOIN 
	((SELECT customer_id ht_id, customer_nickname name, avator FROM tb_responsibility WHERE manager_id = p_manager_id AND customer_id = p_customer_id) UNION (SELECT ht_id, manager_name name, avator FROM tb_manager)) avator_dict
#	((SELECT ht_id, name name, avator FROM tb_customer) UNION (SELECT ht_id, manager_name name, avator FROM tb_manager)) avator_dict
	ON tb_message.from = avator_dict.ht_id
	WHERE (`to` = p_manager_id AND `from` = p_customer_id ) 
		OR (`to` = p_customer_id AND `from` = p_manager_id )
	ORDER BY time DESC
	LIMIT p_limit_exec OFFSET p_skip_exec;
END//
DELIMITER ;

-- 傾印  程序 db_lexus_cs.sp_select_talk_tricks 結構
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_select_talk_tricks`(
	IN `p_manager_id` VARCHAR(50) ,
	IN `p_ans_ID` VARCHAR(20)

)
BEGIN
	/* 20181022 By Ben */
	/* call sp_select_talk_tricks("SE0001","D0002"); */
	IF p_ans_ID = "NORMAL" THEN
		SET p_ans_ID = "NORMAL%";
	END IF;
	
	IF EXISTS (
		SELECT dialog_id,talk_tricks FROM tb_talk_tricks WHERE manager_id = p_manager_id AND dialog_id like p_ans_ID
	)THEN
		SELECT dialog_id,talk_tricks FROM tb_talk_tricks WHERE manager_id = p_manager_id AND dialog_id like p_ans_ID;
	ELSE 
		SELECT dialog_id,talk_tricks FROM tb_talk_tricks_default WHERE dialog_id like p_ans_ID;
	END IF;
	
END//
DELIMITER ;

-- 傾印  程序 db_lexus_cs.sp_send_message 結構
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_send_message`(
	IN `p_message_id` VARCHAR(40),
	IN `p_message_type` VARCHAR(20),
	IN `p_content` VARCHAR(2000),
	IN `p_intent_str` VARCHAR(2000),
	IN `p_recognition_result` VARCHAR(2000),
	IN `p_time` VARCHAR(20),
	IN `p_direction` VARCHAR(20),
	IN `p_from_id` VARCHAR(50),
	IN `p_to_id` VARCHAR(50),
	IN `p_push` VARCHAR(20),
	IN `p_time_record` VARCHAR(500)


)
BEGIN
	/* 20181022 By Ben */
	/* call sp_send_message("text","哈囉","[]","","1540190376871","client","C0003","SE0001","{\"r_time\":\"123\"}"); */
	/* call sp_send_message("text","哈囉","[]","","1540190376871","service","SE0001","C0003","{\"r_time\":\"123\"}"); */
	DECLARE p_customer_id varchar(40);
	DECLARE p_sender_name varchar(40) DEFAULT "你";
	DECLARE p_manager_id varchar(40);
	DECLARE p_last_message varchar(40);
	DECLARE p_conversation_title varchar(60);
	DECLARE p_conversation_avator varchar(100);
	DECLARE p_set_unread int;
	DECLARE p_datetime varchar(30);
	SET p_datetime = FROM_UNIXTIME(p_time/1000);
	#SET p_datetime = CONVERT_TZ(FROM_UNIXTIME(p_time/1000), '+00:00', '+08:00');
	
	IF p_direction = 'service' THEN
		SET p_customer_id = p_to_id;
		SET p_manager_id = p_from_id;
		SET p_set_unread = 0;
	END IF;
	IF  p_direction = 'client' THEN
		SET p_customer_id = p_from_id;
		SET p_manager_id = p_to_id;
		SET p_set_unread = 1;
	END IF;
	
	
	INSERT INTO tb_message
	(`message_id`, `message_type`, `content`, `time`, `assistant_ans`, `visualrecog_ans`, `direction_type`, `from`, `to`, `push`, `time_record`) 
	VALUES
	(p_message_id, p_message_type, p_content, p_datetime, p_intent_str, p_recognition_result, p_direction, p_from_id, p_to_id, p_push, p_time_record);
		
	IF EXISTS (
		SELECT responsibility_id FROM tb_responsibility WHERE manager_id = p_manager_id AND customer_id = p_customer_id
	)THEN
		IF p_direction = 'client' THEN
	   	SET p_sender_name = (SELECT customer_nickname FROM tb_responsibility WHERE manager_id = p_manager_id AND customer_id = p_customer_id LIMIT 0,1);
	  	END IF;
	  	IF p_message_type="image" THEN
	   	SET p_content = CONCAT(p_sender_name," 送出了一張圖片");
	  	END IF;
		UPDATE tb_responsibility SET last_talk_time = p_datetime, last_message =  p_content, 
			manager_unread = (manager_unread+1)*p_set_unread, customer_unread = (customer_unread+1)*IF(p_set_unread=1,0,1)
		WHERE manager_id = p_manager_id AND customer_id = p_customer_id;
		/*
	ELSE 
		SET p_conversation_title = (
				SELECT CONCAT(vehicle_type,"/",vehicle_number,"/",name) 
				FROM tb_customer 
				WHERE ht_id = p_customer_id limit 0,1
			);
		SET p_conversation_avator = (
				SELECT avator 
				FROM tb_customer 
				WHERE ht_id = p_customer_id limit 0,1
			);
		SET p_conversation_title = IFNULL(p_conversation_title, CONCAT("未知的使用者: "+p_customer_id));
		SET p_conversation_avator = IFNULL(p_conversation_avator, "https://customer-service-xiang.herokuapp.com/images/avatar.png");
		INSERT INTO tb_responsibility 
		(`responsibility_id`, `manager_id`, `customer_id`, `conversation_title`, `avator`, `last_talk_time`, `last_message`, `manager_unread`,`customer_unread`,`notify_data`,`personal_data`)
		VALUES
		(UUID(), p_manager_id, p_customer_id, p_conversation_title, p_conversation_avator,  p_datetime, p_content, 0, 0, p_notify_data, p_personal_data);
		*/
	END IF;
	
END//
DELIMITER ;

-- 傾印  程序 db_lexus_cs.sp_update_manager 結構
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_manager`(
	IN `p_manager_id` VARCHAR(50),
	IN `p_compid` VARCHAR(20),
	IN `p_dlrcd` VARCHAR(20),
	IN `p_brnhcd` VARCHAR(20),
	IN `p_sectcd` VARCHAR(20),
	IN `p_manager_type` VARCHAR(50),
	IN `p_manager_name` VARCHAR(20),
	IN `p_avator` VARCHAR(200),
	IN `p_telphone` VARCHAR(20),
	IN `p_personal_data` VARCHAR(2000)







)
    NO SQL
BEGIN
	/* 20181022 By Ben */
	/* call sp_update_manager("SE0001","CostomerService","帥哥志豪",'https://customer-service-xiang.herokuapp.com/images/Lexus_icon.png', '0919863010', '{"討厭的維修時間":"平日上班"}'); */
	IF NOT EXISTS (
		SELECT manager_id FROM tb_manager WHERE ht_id = p_manager_id 
	)THEN
		INSERT INTO tb_manager (`manager_id`, `ht_id`, `login`, `compid`, `dlrcd`, `brnhcd`, `sectcd`, `manager_type`, `manager_name`, `avator`, `telphone`, `personal_data`, `personal_data_time`) 
		VALUES (UUID(), p_manager_id, "Y", p_compid, p_dlrcd, p_brnhcd, p_sectcd, p_manager_type, p_manager_name, p_avator, p_telphone, p_personal_data, NOW());
	ELSE 
		UPDATE tb_manager SET 
			login='Y', 
			compid=p_compid,
			dlrcd=p_dlrcd,
			brnhcd=p_brnhcd,
			sectcd=p_sectcd,
			manager_type=p_manager_type,
			manager_name=p_manager_name,
			avator=p_avator,
			telphone=p_telphone,
			personal_data=p_personal_data,
			personal_data_time=NOW()
		WHERE ht_id = p_manager_id;
	END IF;
	
END//
DELIMITER ;

-- 傾印  程序 db_lexus_cs.sp_update_talk_tricks 結構
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_talk_tricks`(IN `p_manager_id` VARCHAR(50), IN `p_type` VARCHAR(50), IN `p_dialog_id` VARCHAR(20), IN `p_talk_tricks` VARCHAR(2000))
    NO SQL
BEGIN
	/* 20181022 By Ben */
	/* call sp_update_talk_tricks("SE0001","dialog","D0002",'["息怒","妳個混帳","我也是笑笑"]'); */
	IF EXISTS (
		SELECT talk_tricks FROM tb_talk_tricks WHERE manager_id = p_manager_id AND dialog_id = p_dialog_id
	)THEN
		UPDATE tb_talk_tricks SET talk_tricks = p_talk_tricks WHERE manager_id = p_manager_id AND dialog_id = p_dialog_id;
	ELSE 
		INSERT INTO tb_talk_tricks ( `type`, `manager_id`, `dialog_id`, `talk_tricks`) VALUES (p_type,p_manager_id,p_dialog_id,p_talk_tricks);
	END IF;
	
END//
DELIMITER ;

-- 傾印  表格 db_lexus_cs.tb_call_api_log 結構
CREATE TABLE IF NOT EXISTS `tb_call_api_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL,
  `start` varchar(50) DEFAULT NULL,
  `end` varchar(50) DEFAULT NULL,
  `success` varchar(20) DEFAULT NULL,
  `params` varchar(2000) DEFAULT NULL,
  `data` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8;

-- 正在傾印表格  db_lexus_cs.tb_call_api_log 的資料：~120 rows (大約)
/*!40000 ALTER TABLE `tb_call_api_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_call_api_log` ENABLE KEYS */;

-- 傾印  表格 db_lexus_cs.tb_customer 結構
CREATE TABLE IF NOT EXISTS `tb_customer` (
  `customer_id` char(40) NOT NULL,
  `ht_id` varchar(50) DEFAULT NULL,
  `login` varchar(50) DEFAULT 'N',
  `name` varchar(20) DEFAULT NULL,
  `vehicle_type` varchar(20) DEFAULT NULL,
  `vehicle_number` varchar(20) DEFAULT NULL,
  `avator` varchar(200) DEFAULT NULL,
  `telphone` varchar(20) DEFAULT NULL,
  `fend_date` varchar(20) DEFAULT NULL,
  `uend_date` varchar(20) DEFAULT NULL,
  `birth_date` varchar(20) DEFAULT NULL,
  `fend_need_notify` varchar(10) DEFAULT NULL,
  `uend_need_notify` varchar(10) DEFAULT NULL,
  `birth_need_notify` varchar(10) DEFAULT NULL,
  `fend_notify` varchar(10) DEFAULT 'Y',
  `uend_notify` varchar(10) DEFAULT 'Y',
  `birth_notify` varchar(10) DEFAULT 'Y',
  `personal_data` varchar(2000) DEFAULT NULL,
  `personal_data_time` datetime DEFAULT NULL,
  `memo` varchar(200) DEFAULT '',
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  db_lexus_cs.tb_customer 的資料：~12 rows (大約)
/*!40000 ALTER TABLE `tb_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_customer` ENABLE KEYS */;

-- 傾印  表格 db_lexus_cs.tb_manager 結構
CREATE TABLE IF NOT EXISTS `tb_manager` (
  `manager_id` char(40) NOT NULL,
  `ht_id` varchar(50) DEFAULT NULL,
  `login` varchar(10) DEFAULT 'N',
  `compid` varchar(20) DEFAULT NULL,
  `dlrcd` varchar(20) DEFAULT NULL,
  `brnhcd` varchar(20) DEFAULT NULL,
  `sectcd` varchar(20) DEFAULT NULL,
  `manager_type` varchar(50) DEFAULT NULL,
  `manager_name` varchar(50) DEFAULT NULL,
  `avator` varchar(200) DEFAULT NULL,
  `telphone` varchar(50) DEFAULT NULL,
  `personal_data` varchar(50) DEFAULT NULL COMMENT '預想是jsonstr',
  `personal_data_time` datetime DEFAULT NULL,
  `memo` varchar(200) DEFAULT '',
  PRIMARY KEY (`manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  db_lexus_cs.tb_manager 的資料：~4 rows (大約)
/*!40000 ALTER TABLE `tb_manager` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_manager` ENABLE KEYS */;

-- 傾印  表格 db_lexus_cs.tb_message 結構
CREATE TABLE IF NOT EXISTS `tb_message` (
  `message_id` char(40) NOT NULL,
  `message_type` varchar(20) DEFAULT NULL,
  `content` varchar(2000) DEFAULT NULL,
  `time` datetime(3) DEFAULT NULL,
  `assistant_ans` varchar(2000) DEFAULT NULL,
  `visualrecog_ans` varchar(2000) DEFAULT NULL,
  `direction_type` varchar(20) DEFAULT NULL,
  `from` varchar(50) DEFAULT NULL,
  `to` varchar(50) DEFAULT NULL,
  `push` varchar(20) DEFAULT NULL,
  `time_record` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  db_lexus_cs.tb_message 的資料：~25 rows (大約)
/*!40000 ALTER TABLE `tb_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_message` ENABLE KEYS */;

-- 傾印  表格 db_lexus_cs.tb_responsibility 結構
CREATE TABLE IF NOT EXISTS `tb_responsibility` (
  `responsibility_id` char(40) NOT NULL,
  `manager_id` char(40) DEFAULT NULL,
  `customer_id` char(40) DEFAULT NULL,
  `conversation_title` varchar(60) DEFAULT NULL COMMENT '避免為了名字而每次join',
  `customer_nickname` varchar(60) DEFAULT NULL,
  `avator` varchar(200) DEFAULT NULL,
  `last_talk_time` datetime DEFAULT NULL,
  `last_message` varchar(200) DEFAULT NULL,
  `manager_unread` int(11) DEFAULT NULL,
  `customer_unread` int(11) DEFAULT NULL,
  `notify_data` varchar(200) DEFAULT NULL,
  `memo` varchar(200) DEFAULT '',
  PRIMARY KEY (`responsibility_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  db_lexus_cs.tb_responsibility 的資料：~14 rows (大約)
/*!40000 ALTER TABLE `tb_responsibility` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_responsibility` ENABLE KEYS */;

-- 傾印  表格 db_lexus_cs.tb_talk_tricks 結構
CREATE TABLE IF NOT EXISTS `tb_talk_tricks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) DEFAULT NULL,
  `manager_id` varchar(50) DEFAULT NULL,
  `dialog_id` varchar(20) DEFAULT NULL,
  `talk_tricks` varchar(2000) DEFAULT NULL COMMENT '預期是jsonarray',
  `memo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- 正在傾印表格  db_lexus_cs.tb_talk_tricks 的資料：~1 rows (大約)
/*!40000 ALTER TABLE `tb_talk_tricks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_talk_tricks` ENABLE KEYS */;

-- 傾印  表格 db_lexus_cs.tb_talk_tricks_default 結構
CREATE TABLE IF NOT EXISTS `tb_talk_tricks_default` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dialog_id` varchar(20) DEFAULT NULL,
  `talk_tricks` varchar(2000) DEFAULT NULL,
  `memo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=370 DEFAULT CHARSET=utf8;

-- 正在傾印表格  db_lexus_cs.tb_talk_tricks_default 的資料：~236 rows (大約)
/*!40000 ALTER TABLE `tb_talk_tricks_default` DISABLE KEYS */;
INSERT INTO `tb_talk_tricks_default` (`id`, `dialog_id`, `talk_tricks`, `memo`) VALUES
	(134, 'D1001', '["要視車子的使用狀況，基本上回廠保養都會幫您做電瓶的檢測"]', '故障詢問_電瓶壽命'),
	(135, 'D1002', '["顯示電瓶電量低表示系統正在充電暫時無法使用怠速熄火的功能"]', '故障詢問_電瓶電量低電量'),
	(136, 'D1003', '["在儀表板上會提醒「檢查混合動力系統」，請您盡速回廠檢查測試"]', '故障詢問_Hybrid系統異常'),
	(137, 'D1004', '["部份油電車配有行人提示蜂鳴器將會發出蜂鳴聲提醒路人"]', '故障詢問_Hybrid行人提示蜂鳴器'),
	(138, 'D1005', '["可能是冷媒量不足或冷氣零件有損害等皆有可能造成，煩請您回廠檢查確認原因"]', '故障詢問_空調暖氣通風功效低不夠冷'),
	(139, 'D1006', '["可能是冷氣控制系統的問題，請您回廠檢查確認原因"]', '故障詢問_空調暖氣通風故障忽冷忽熱冷熱同時'),
	(140, 'D1007', '["胎壓過高可能會造成胎紋中間部份過度磨損，使接地面積減少，容易抓地力不足"]', '故障詢問_胎壓監測異常過高'),
	(141, 'D1008', '["胎壓過低可能會造成胎紋兩側部份過度磨損，建議回廠檢查"]', '故障詢問_胎壓監測異常過低'),
	(142, 'D1009', '["胎壓能迅速了解輪胎狀況，可即早發現輪胎中釘，並減少爆胎意外的發生"]', '故障詢問_胎壓監測胎壓偵測器說明'),
	(143, 'D1010', '["售後加裝大概約五千多元，但不同車型價格不同，還是要依報價。"]', '故障詢問_胎壓監測胎壓偵測器價格'),
	(144, 'D1011', '["可能是雨刷片不良或者玻璃有油膜殘留，需回廠檢查確認"]', '故障詢問_雨刷清洗器異常刷不乾淨'),
	(145, 'D1012', '["噴水頭可能有損壞或需要調整，您找時間回廠幫您檢查確認"]', '故障詢問_雨刷清洗器異常噴霧不良'),
	(146, 'D1013', '["可以自己加原廠雨刷精或自來水，建議勿添加洗碗精或其他玻璃清潔用品，以免沈澱造成水箱長青苔與噴水馬達咬死。"]', '故障詢問_雨刷清洗器異常噴水桶缺水'),
	(147, 'D1014', '["回廠我幫您檢查原因"]', '故障詢問_雨刷清洗器異常異音'),
	(148, 'D1015', '["可能是馬達內部短(斷)路或電阻過高，安排回廠幫您檢查確認原因"]', '故障詢問_雨刷清洗器噴水馬達可能原因'),
	(149, 'D1016', '["如果確認損壞，需要先訂貨，再安排時間回廠安裝"]', '故障詢問_雨刷清洗器噴水馬達處理'),
	(150, 'D1017', '["更換時間大概1個小時，但不包含其他保養時間"]', '故障詢問_雨刷清洗器噴水馬達工時'),
	(151, 'D1018', '["我們服務廠提供的是橫濱輪胎，橫濱為日本前三大品牌，品質穩定值得信賴"]', '故障詢問_輪胎車輪簡介'),
	(152, 'D1019', '["您再安排時間回廠，我會請技師幫您檢查"]', '故障詢問_輪胎車輪異常異音'),
	(153, 'D1020', '["當胎紋磨損至1.6mm時，應立即回廠更換新輪胎"]', '故障詢問_輪胎車輪異常自檢'),
	(154, 'D1021', '["我查詢系統後，告訴您上次輪胎的更換日期"]', '故障詢問_輪胎車輪異常查詢'),
	(155, 'D1022', '["在定期保養時會視實際需要實施調輪平衡"]', '故障詢問_輪胎車輪異常輪胎調整'),
	(156, 'D1023', '["您可直接回廠我來幫您處理的"]', '故障詢問_輪胎車輪保養輪胎蠟'),
	(157, 'D1024', '["不見得會，要看輪胎是否有受傷，或貓眼石是否有破損，但能避就要避開"]', '故障詢問_輪胎車輪意外貓眼石爆胎'),
	(158, 'D1025', '["檢測輪胎跟底盤機構的正確性，若超出標準值會建議做定位調整或更換零件"]', '故障詢問_輪胎車輪四輪定位檢測說明'),
	(159, 'D1026', '["我詢問過了，校正後師傅沒有存下來，真的很抱歉"]', '故障詢問_輪胎車輪四輪定位檢測車主要圖_沒圖'),
	(160, 'D1027', '["車子大燈是可以調整的，但是有限度的調整，需要回廠幫您確認"]', '故障詢問_燈光方向燈頭燈車燈調整'),
	(161, 'D1028', '["可以的話先用塑膠布或防水布封住，然後盡快安排回廠處理"]', '故障詢問_燈光方向燈頭燈車燈燈罩破掉'),
	(162, 'D1029', '["燈泡需要幫您訂料，請問需要嗎？"]', '故障詢問_燈光方向燈頭燈車燈燈泡壞掉破掉'),
	(163, 'D1030', '["原廠沒有單賣LED燈泡，只有燈總成"]', '故障詢問_燈光方向燈頭燈Led燈泡說明'),
	(164, 'D1031', '["先幫您確認庫存，再另外安排時間回廠安裝"]', '故障詢問_燈光方向燈頭燈Led燈泡訂購'),
	(165, 'D1032', '["引擎機油在油道內長期會殘留油泥，容易造成阻塞，因此需定期清洗"]', '故障詢問_引擎本體油道清洗說明'),
	(166, 'D1033', '["大約3,000到3,600元不等，但要依您的車型幫您查詢價格"]', '故障詢問_引擎本體油道清洗費用'),
	(167, 'D1034', '["回廠我幫您檢查確認原因"]', '故障詢問_引擎本體異常異音'),
	(168, 'D1035', '["有可能是引擎蓋六角鎖、車身板金或是其他問題，回廠我幫您檢查確認"]', '故障詢問_引擎本體異常縫隙'),
	(169, 'D1036', '["建議拖吊入廠處理，撥打0800-091-091與LEXUS道路救援聯繫"]', '故障詢問_引擎本體故障無法啟動'),
	(170, 'D1037', '["回廠我幫您檢查確認原因"]', '故障詢問_引擎本體引擎蓋異常'),
	(171, 'D1038', '["可以的，您要安排什麼時候入廠呢？"]', '故障詢問_引擎本體引擎蓋異常想檢查'),
	(172, 'D1039', '["煞車碟盤是與車輪一起旋轉的旋轉盤，當踩煞車時，煞車片和碟盤產生磨擦力，以煞車力使車子減速"]', '故障詢問_煞車煞車盤說明'),
	(173, 'D1040', '["煞車盤跟煞車皮他們會互相磨損，煞車盤將於每次保養會進行檢查判定是否需汱換"]', '故障詢問_煞車煞車盤壽命'),
	(174, 'D1041', '["更換煞車盤大概需要1個小時，但不包含其他保養時間"]', '故障詢問_煞車煞車盤工時'),
	(175, 'D1042', '["與煞車碟盤接觸的耐磨部件，它被安裝在煞車分泵，對煞車碟盤施加的壓力讓汽車達到減速的目的"]', '故障詢問_煞車煞車來令說明'),
	(176, 'D1043', '["檢查煞車片的厚度低於3mm或者是異常磨損，就必須立即更換煞車塊。"]', '故障詢問_煞車煞車來令更換時機'),
	(177, 'D1044', '["為了您的行車安全及消除疑慮，煩請安排回廠檢查確認原因"]', '故障詢問_煞車異常異音'),
	(178, 'D1045', '["當系統判定很有可能會正面撞擊到車輛時，便會發出警示敦促駕駛人採取閃避動作(細節可參考車主手冊)"]', '故障詢問_煞車PCS預警式防護系統警示提醒'),
	(179, 'D1046', '["增加可能的煞車壓力，以協助駕駛人減少撞擊(細節可參考車主手冊)"]', '故障詢問_煞車PCS預警式防護系統增加煞車力道'),
	(180, 'D1047', '["當系統判定極有可能會撞擊車輛時，便會自動煞車，減少撞擊力道(細節可參考車主手冊)"]', '故障詢問_煞車PCS預警式防護系統自動煞車輔助'),
	(181, 'D1048', '["在多功能資訊顯示幕上開啟PCS(預警式防護系統)"]', '故障詢問_煞車PCS預警式防護系統設定方式'),
	(182, 'D1049', '["太舊的煞車油或劣化的，會導致沸點降低，嚴重會使煞車不靈，影響行車安全"]', '故障詢問_煞車煞車油說明'),
	(183, 'D1050', '["建議每2年或4萬公里要更換"]', '故障詢問_煞車煞車油壽命'),
	(184, 'D1051', '["更換煞車油大概需要1個小時，但不包含其他保養時間"]', '故障詢問_煞車煞車油工時'),
	(185, 'D1052', '["煞車油液位高度在煞車塊磨損的情況下會稍微下降，這是正常的現象。如果儲液筒須要經常補充，則可能表示有嚴重的問題。"]', '故障詢問_煞車煞車油油位高度太低太高'),
	(186, 'D1053', '["有在方向盤的左下方、實體的P開關、EMV(Remote Touch螢幕)及MID(多功能資訊顯示幕)中可以設定(打開偵測雷達)"]', '故障詢問_倒車雷達及其偵測系統按鈕位置說明'),
	(187, 'D1054', '["實體的按鈕「P」可以開啟或關閉偵測雷達功能"]', '故障詢問_倒車雷達及其偵測系統按鈕功能開關'),
	(188, 'D1055', '["部份車型可以在「設定」調整偵測雷達的音量大小"]', '故障詢問_倒車雷達及其偵測系統按鈕功能大小聲'),
	(189, 'D1056', '["請您回廠檢查，服務廠會幫您重新安裝測試，但若是檢查發現零件損壞則需另外訂料幫您安裝"]', '故障詢問_倒車雷達及其偵測異常鬆掉脫落'),
	(190, 'D1057', '["安裝偵測雷達大概需要1小時，但不包含其他保養時間"]', '故障詢問_倒車雷達及其偵測安裝工時'),
	(191, 'D1058', '["目前沒有提供加裝倒車顯影的服務"]', '故障詢問_倒車雷達及其偵測倒車顯影加裝'),
	(192, 'D1059', '["安排回廠我來幫您處理"]', '故障詢問_底盤整體底盤機件生鏽處理'),
	(193, 'D1060', '["磨損、間隙、干涉都可能會造成這個狀況，建議回來入廠檢查"]', '故障詢問_底盤整體底盤機件異音振動偏向'),
	(194, 'D1061', '["主要作用是幫助冷卻水降溫，透過降溫後的水流至引擎發揮散熱效果，形成引擎散熱的循環"]', '故障詢問_冷卻水箱水管泵浦節溫器水箱說明'),
	(195, 'D1062', '["水箱如確定漏水，建議拖吊入廠處理"]', '故障詢問_冷卻水箱水管泵浦節溫器異常損壞漏水'),
	(196, 'D1063', '["回廠保養時會幫您定期檢查及更換"]', '故障詢問_冷卻水箱水管泵浦節溫器處理換水'),
	(197, 'D1064', '["冷卻液量不足，請添加水箱專用冷卻液、蒸餾水或是自來水，建議您盡速回廠做檢查處理"]', '故障詢問_冷卻水箱水管泵浦節溫器處理緊急處理'),
	(198, 'D1065', '["水箱如確定漏水需更換需4個小時，但不包含其他保養時間"]', '故障詢問_冷卻水箱水管泵浦節溫器處理工時'),
	(199, 'D1066', '["我們沒有在回收廢水箱，但是會依資源回收管道幫您妥善地處理廢棄的水箱"]', '故障詢問_冷卻水箱水管泵浦節溫器處理回收'),
	(200, 'D1067', '["回廠確認損壞狀況，如有需要可以幫您訂料更換"]', '故障詢問_冷卻水箱水管泵浦節溫器水箱護罩原車型'),
	(201, 'D1068', '["為了您的行車安全及消除疑慮，煩請安排回廠檢查確認原因"]', '故障詢問_尾門行李箱燈不亮'),
	(202, 'D1069', '["更換方向機大概需要1-2天，但不包含其他保養時間"]', '故障詢問_方向機柱軸處理工時'),
	(203, 'D1070', '["HV電池不良，我會訂料再安排過去您那牽車回廠處理"]', '故障詢問_綜合儀表燈號檢查混合動力系統'),
	(204, 'D1071', '["引擎故障燈亮可能是電子控制或變速箱有問題，立即回廠幫您檢修"]', '故障詢問_綜合儀表燈號引擎故障燈'),
	(205, 'D1072', '["BSM是盲點偵測開啟的意思，燈是綠色的都是沒問題的"]', '故障詢問_綜合儀表燈號BSM'),
	(206, 'D1073', '["RCTA是後方交通偵測開啟，燈是綠色的都是沒問題的"]', '故障詢問_綜合儀表燈號RCTA'),
	(207, 'D1074', '["胎壓警示燈亮可能是因天氣或輪胎漏氣而導致胎壓降低，請立即將車輛停在安全的地點，撥打0800-091-091救援專線"]', '故障詢問_綜合儀表燈號胎壓'),
	(208, 'D1075', '["Eco是您在滑行沒踩油門就會亮燈/Eco節能 亮燈表示目前節能"]', '故障詢問_綜合儀表燈號Eco'),
	(209, 'D1076', '["儀表板右上方綠色的「P」亮燈表示停車雷達已開啟"]', '故障詢問_綜合儀表燈號P'),
	(210, 'D1077', '["計算目前車輛的油耗狀態(詳情請參考車主手冊)"]', '故障詢問_綜合儀表燈號油耗'),
	(211, 'D1078', '["您再安排時間回廠，我會請技師幫您檢查"]', '故障詢問_綜合儀表燈號其他'),
	(212, 'D1079', '["方向盤可以調整上下左右，調整鈕在方向盤的左側下方"]', '故障詢問_方向盤調整位置'),
	(213, 'D1080', '["是什麼樣的聲音？是在什麼情況下發生的？聲音頻繁嗎？"]', '故障詢問_方向盤異常異音'),
	(214, 'D1081', '["為了您的行車安全及消除疑慮，煩請安排回廠檢查確認原因"]', '故障詢問_方向盤處理回廠檢查'),
	(215, 'D1082', '["主要作用為使動力方向機、泵浦及油管傳輸的液壓油"]', '故障詢問_方向盤轉向系統的動力油說明'),
	(216, 'D1083', '["建議每5萬公里更換(檢查更換)"]', '故障詢問_方向盤轉向系統的動力油壽命'),
	(217, 'D1084', '["動力方向盤油不足會造成方向盤轉動會過重或卡滯的狀況"]', '故障詢問_方向盤轉向系統的動力油不足的影響'),
	(218, 'D1085', '["您在哪裡呢？可以的話過去幫您處理","可以撥打0800-091-091與LEXUS道路救援聯繫"]', '故障詢問_電瓶電量沒電發不動'),
	(219, 'D1086', '["是什麼樣的聲音？是在什麼情況下發生的？聲音頻繁嗎？","為了您的行車安全及消除疑慮，煩請安排回廠檢查確認原因"]', '故障詢問_空調暖氣通風異常異音'),
	(220, 'D1087', '["異味要回廠檢查才能幫您確認原因","如果確定是冷氣裡面傳出異味，處理方法是清潔冷氣管路"]', '故障詢問_空調暖氣通風異常異味'),
	(221, 'D1088', '["如果是滴水的話，可能原因是冷氣管路跟空氣溫差產生的冷凝水，如果您有的安全疑慮，煩請安排回廠檢查確認原因","如果是漏水的話，有可能是冷氣管線的安裝不良或有損壞，建議回廠幫您處理"]', '故障詢問_空調暖氣通風出水'),
	(222, 'D1089', '["每次回廠保養時我們都可以幫您做檢查，如果太髒會建議您更換","我們有提供冷氣管路清潔的保養套餐"]', '故障詢問_空調暖氣通風清潔'),
	(223, 'D1090', '["產生臭氧(濃度0.02PPM)，有效清除車內細菌，保持空氣清新自然","我們有提供臭氧機，可以回廠幫您安裝"]', '故障詢問_空調暖氣通風臭氧機空調活氧裝置'),
	(224, 'D1091', '["駕駛側的車門邊有標準胎壓磅數可以參考","當前胎壓數值低於設定值的20-25%燈就會亮起來"]', '故障詢問_胎壓監測簡介'),
	(225, 'D1092', '["確認輪胎如果沒明顯漏氣，有可能天氣太冷、中釘子或太久未檢查都可能會讓胎壓變化","建議回廠檢查"]', '故障詢問_胎壓監測處理'),
	(226, 'D1093', '["碟盤現在是磨損情形，還能使用所以我們會做車削整平動作，如果再深一點就要換掉","使用太久、磨損、吃溝或鏽蝕太嚴重，需更換新的煞車盤"]', '故障詢問_煞車煞車盤處理'),
	(227, 'D1094', '["行李箱的高度無法調整，抱歉","休旅車可以設定後箱開啟高度的功能(可參考車主手冊設定)"]', '故障詢問_尾門行李箱高度設定'),
	(228, 'D1095', '["是什麼樣的聲音？是在什麼情況下發生的？聲音頻繁嗎？","為了您的行車安全及消除疑慮，煩請安排回廠檢查確認原因"]', '故障詢問_藍芽音響異常異音處理'),
	(229, 'D1096', '["音響mute功能在會方向盤的左側或右側，看到MODE鍵長按，即可使用","手機打開藍芽，與車上的音響做配對","手機打開藍芽，搜尋藍芽名稱「LEXUS」配對，即可使用"]', '故障詢問_藍芽音響功能設定說明'),
	(230, 'D1097', '["高速行駛時方向盤抖動，有可能是輪胎平衡不好，回廠才能幫您確認原因","踩煞車方向盤抖動，有可能是碟盤或煞車片的煞車問題，回廠才能幫您確認原因","磨損、間隙、干涉都可能會造成這個狀況，建議回來入廠檢查"]', '故障詢問_方向盤異常抖動'),
	(231, 'D1098', '["按照車輛當時販售的規格與配備，該車沒有配備此功能","車輛販售的規格與配備，詳細規格可以看官網頁面(https://www.lexus.com.tw)"]', '故障詢問_車門含車門功能件自動鎖門說明'),
	(232, 'D1099', '["車門上鎖功能你可以在Remote Touch螢幕的「設定」選項內可以進行調整"]', '故障詢問_車門含車門功能件車門上鎖設定'),
	(233, 'D2001', '["手機打開藍芽，與車上的音響做配對"]', '故障詢問方向_功能'),
	(234, 'D2002', '["我們有提供臭氧機，可以回廠幫您安裝"]', '故障詢問方向_安裝'),
	(235, 'D2003', '["有在方向盤的左下方、實體的P開關、EMV(Remote Touch螢幕)及MID(多功能資訊顯示幕)中可以設定(打開偵測雷達)","實體的按鈕「P」可以開啟或關閉偵測雷達功能","部份車型可以在「設定」調整偵測雷達的音量大小"]', '故障詢問方向_系統按鈕'),
	(236, 'D2004', '["車子大燈是可以調整的，但是有限度的調整，需要回廠幫您確認"]', '故障詢問方向_車燈'),
	(237, 'D2005', '["可能是冷氣控制系統的問題，請您回廠檢查確認原因","建議拖吊入廠處理，撥打0800-091-091與LEXUS道路救援聯繫"]', '故障詢問方向_故障'),
	(238, 'D2006', '["高速行駛時方向盤抖動，有可能是輪胎平衡不好，回廠才能幫您確認原因","胎壓過高可能會造成胎紋中間部份過度磨損，使接地面積減少，容易抓地力不足","胎壓過低可能會造成胎紋兩側部份過度磨損，建議回廠檢查","回廠我幫您檢查確認原因","水箱如確定漏水，建議拖吊入廠處理"]', '故障詢問方向_異常'),
	(239, 'D2007', '["每次回廠保養時我們都可以幫您做檢查，如果太髒會建議您更換","我們有提供冷氣管路清潔的保養套餐"]', '故障詢問方向_清潔'),
	(240, 'D2008', '["建議回廠檢查","冷卻液量不足，請添加水箱專用冷卻液、蒸餾水或是自來水，建議您盡速回廠做檢查處理","在定期保養時會視實際需要實施調輪平衡","使用太久、磨損、吃溝或鏽蝕太嚴重，需更換新的煞車盤","安排回廠我來幫您處理"]', '故障詢問方向_處理'),
	(241, 'D2009', '["不見得會，要看輪胎是否有受傷，或貓眼石是否有破損，但能避就要避開"]', '故障詢問方向_意外'),
	(242, 'D2010', '["要視車子的使用狀況，基本上回廠保養都會幫您做電瓶的檢測","煞車盤跟煞車皮他們會互相磨損，煞車盤將於每次保養會進行檢查判定是否需汱換","建議每2年或4萬公里要更換","建議每5萬公里更換(檢查更換)"]', '故障詢問方向_壽命'),
	(243, 'D2011', '["方向盤可以調整上下左右，調整鈕在方向盤的左側下方"]', '故障詢問方向_調整'),
	(244, 'D2012', '["HV電池不良，我會訂料再安排過去您那牽車回廠處理","引擎故障燈亮可能是電子控制或變速箱有問題，立即回廠幫您檢修","BSM是盲點偵測開啟的意思，燈是綠色的都是沒問題的","RCTA是後方交通偵測開啟，燈是綠色的都是沒問題的","胎壓警示燈亮可能是因天氣或輪胎漏氣而導致胎壓降低，請立即將車輛停在安全的地點，撥打0800-091-091救援專線","Eco是您在滑行沒踩油門就會亮燈/Eco節能 亮燈表示目前節能","儀表板右上方綠色的「P」亮燈表示停車雷達已開啟","計算目前車輛的油耗狀態(詳情請參考車主手冊)"]', '故障詢問方向_燈號'),
	(245, 'D2013', '["主要作用為使動力方向機、泵浦及油管傳輸的液壓油","駕駛側的車門邊有標準胎壓磅數可以參考","按照車輛當時販售的規格與配備，該車沒有配備此功能","與煞車碟盤接觸的耐磨部件，它被安裝在煞車分泵，對煞車碟盤施加的壓力讓汽車達到減速的目的","引擎機油在油道內長期會殘留油泥，容易造成阻塞，因此需定期清洗"]', '故障詢問方向_說明'),
	(246, 'D2014', '["更換煞車盤大概需要1個小時，但不包含其他保養時間","更換煞車油大概需要1個小時，但不包含其他保養時間","安裝偵測雷達大概需要1小時，但不包含其他保養時間","水箱如確定漏水需更換需4個小時，但不包含其他保養時間","更換方向機大概需要1-2天，但不包含其他保養時間"]', '故障詢問方向_工時'),
	(247, 'D4001', '["可以用手機或筆電上官網下載電子檔使用手冊 https://www.lexus.com.tw/owners-login.aspx"]', '業代對話_車主權益_車主手冊_線上'),
	(248, 'D4002', '["只有手冊或電子檔，沒有光碟片呢，抱歉"]', '業代對話_車主權益_車主手冊_光碟'),
	(249, 'D4003', '["定保禮物是公司設定每半年內回廠LEXUS定保套餐才有的喔","定保禮物是公司設定每半年內回廠定保才有的喔，服務廠有體恤顧客忙碌，所以有30天的緩衝時間，讓您安排時間回廠","定保禮物是每季都會更新的產品，我們的定保禮不會重覆"]', '業代對話_車主權益_定保禮物_說明'),
	(250, 'D4004', '["我們每一台車子設定只能領取一份定保禮物，贈品的數量都有控管的，真的不好意思"]', '業代對話_車主權益_定保禮物_多要'),
	(251, 'D4005', '["抱歉，如有順路經過服務廠或是下次回廠，我來幫您更換新的"]', '業代對話_車主權益_定保禮物_損壞'),
	(252, 'D4006', '["這個我幫你爭取看看，是否符合贈送的資格需跟服務廠確認，我盡快回覆您","不好意思，這個定期回廠的定保禮是特別為顧客安排，所以沒辦法更換，我們LEXUS精品有推出類似的商品，可以點數兌換或精品加價購，精品網站：https://www.lexus.com.tw/collection.aspx"]', '業代對話_車主權益_定保禮物_抱怨'),
	(253, 'D4007', '["中信和LEXUS有推出車主專屬聯名卡","維修保養會有紅利集點可抵扣現金及LEXUS精品9折，台北市區最高4小時免費停車，精選餐廳優惠，機場接送或停車等尊榮禮遇","中信LEXUS聯名卡車主享有首年免年費，當年刷卡消費滿50萬(含)以上可享次年免年費，未達消費金額的年費為1萬元"]', '業代對話_車主權益_LEXUS聯名卡_說明'),
	(254, 'D4008', '["填寫聯名卡申請書，附上行照影本、身分證正反面影本、名片及財力證明，交給我後由LEXUS服務廠統一轉送申辦，中信聯名卡網站：https://www.ctbcbank.com/tw/html/long/creditcard/LEXUS/index.html#section-5","填寫聯名卡申請書，附上行照影本、身分證正反面影本及名片，交給我後由LEXUS服務廠統一轉送申辦，中信聯名卡網站：https://www.ctbcbank.com/tw/html/long/creditcard/LEXUS/index.html#section-5","如果是自行辦理的話，準備聯名卡申請書，附上行照影本、身分證正反面影本、名片及財力證明，可以交至各LEXUS營業據點、各中信櫃台或投遞郵箱，中信聯名卡網站：https://www.ctbcbank.com/tw/html/long/creditcard/LEXUS/index.html#section-5"]', '業代對話_車主權益_LEXUS聯名卡_申辦'),
	(255, 'D4009', '["鍍膜是於車身漆面鍍上一層鍍膜層，用於抵擋紫外線及酸雨髒汙等","鍍膜依等級及產品的不同，保護的差異性會有所不同，大部份約可保護車子約2-6個月"]', '業代對話_外觀_鍍膜打蠟_鍍膜'),
	(256, 'D4010', '["打蠟分為粗蠟和美容蠟，是透過打蠟機去拋光車身漆面，去除車身細紋","鍍膜是不用特地打蠟的，鍍膜後只需清水洗淨即可，","若您鍍膜期間過久，發現鍍膜效果不佳，就需再修補鍍膜"]', '業代對話_外觀_鍍膜打蠟_打蠟'),
	(257, 'D4011', '["打蠟會減損車子本身漆面的厚度，而鍍膜是在車身漆面加上一層保護層","站在保養角度，打蠟相較需頻繁性的處理車身漆面，而鍍膜是不需要任何的處置"]', '業代對話_外觀_鍍膜打蠟_差別'),
	(258, 'D4012', '["如果您傾向讓汽車美容店幫您保養清潔車子，建議您可以定期打蠟美容即可","如果您會自行洗車，建議您可以選擇鍍膜，因鍍膜有效期只需清水洗淨，可縮短您的保養清潔時間"]', '業代對話_外觀_鍍膜打蠟_建議'),
	(259, 'D4013', '["補漆可以購買點漆筆，或是回服務廠點漆處理","掉漆可以鈑金修理然後烤漆"]', '業代對話_外觀_掉漆_處理'),
	(260, 'D4014', '["要幫您訂貨點漆筆嗎？"]', '業代對話_外觀_掉漆_訂貨'),
	(261, 'D4015', '["我幫您用車牌號碼查詢，會以電子型錄上的色號，幫您訂購點漆筆","您的車身顏色屬於特殊色號，廠家未提供點漆筆，敬請見諒 "]', '業代對話_外觀_掉漆_色號'),
	(262, 'D4016', '["視覺看起來會有差異主要是因為新舊漆面的顏色亮度差異，舊漆面因太陽光或長期使用會褪色"]', '業代對話_外觀_掉漆_色差'),
	(263, 'D4017', '["清潔座椅可以用溼布擦拭，不用清潔劑是怕會讓皮椅褪色","清潔座椅可以用溼布擦拭，不用清潔劑是怕會讓皮椅褪色，或可以回服務廠幫您用皮革清潔劑為您處理"]', '業代對話_外觀_清潔_座椅'),
	(264, 'D4018', '["有可能是雨刷造成的，建議您回廠檢查檔風玻璃和雨刷的狀況"]', '業代對話_外觀_清潔_雨刷'),
	(265, 'D4019', '["卡片式鑰匙的電池壽命約1.5年","智慧型鑰匙的電池壽命約1至2年"]', '業代對話_配備_鑰匙_壽命'),
	(266, 'D4020', '["多功能顯示幕顯示「Key Battery Low」，代表遙控器電池電力不足需更換","遙控器電池電力不足可以回廠幫您更換電池","遙控器電池電力不足可以在外買同型電池"]', '業代對話_配備_鑰匙_沒電'),
	(267, 'D4021', '["eTag有分成前檔型及車牌型，前檔型是將eTag黏貼於前檔玻璃右下方；而車牌型是將eTag懸掛在前方車牌的上方","若您的車子有貼前檔隔熱紙，如材質會干擾eTag的接收，建議您可以選擇車牌型，將eTag懸掛在前方車牌的上方"]', '業代對話_配備_ETAG_說明'),
	(268, 'D4022', '["如果您有eTag需求的話，我們可以代為申請","如果是自行申請eTag，需準備身份證明文件正本及行照，至遠通電收門市辦理"]', '業代對話_配備_ETAG_申請'),
	(269, 'D4023', '["用手機上遠通官網申請停用即可，並將eTag餘額轉到新車","eTag簡訊於30分鐘內完成驗證即可"]', '業代對話_配備_ETAG_帳戶'),
	(270, 'D4024', '["記得打給信用卡公司申請新車eTag及路邊停車格自動扣款，並將舊車取消自動扣款","目前有遠東商銀、台新、玉山、國泰世華及中信可以申請eTag自動儲值，還享有通行費9折的優惠"]', '業代對話_配備_ETAG_扣款'),
	(271, 'D4025', '["我們有提供行車紀錄器，需要幫您訂購嗎?"]', '業代對話_配備_行車紀錄器_購買'),
	(272, 'D4026', '["為了不破壞車身線路，影響行車安全，服務廠只安裝可外接電源的行車紀錄器，但會收安裝工資","若您購買正廠的行車紀錄器，就含安裝服務了"]', '業代對話_配備_行車紀錄器_安裝'),
	(273, 'D4027', '["您找時間回廠，幫您檢查是什麼問題"]', '業代對話_配備_行車紀錄器_異常'),
	(274, 'D4028', '["我們有提供行車導航，需要幫您訂購嗎?"]', '業代對話_配備_導航_購買'),
	(275, 'D4029', '["您找時間回來看看，幫您檢查是什麼問題","那我幫您約時間請廠商來排除"]', '業代對話_配備_導航_異常'),
	(276, 'D4030', '["可以贈送您隔熱紙，可是我們會依據您的用車需求幫您配"]', '業代對話_配備_隔熱紙_贈送'),
	(277, 'D4031', '["那您需要的貼比較深色的還是淺一點的隔熱紙？","通常我們贈送的型號，在冷房效果都不錯，如果您要升級高階隔熱紙的話，我再另外跟您報價"]', '業代對話_配備_隔熱紙_配適'),
	(278, 'D4032', '["通常進口車的選擇為V-KOOL、FSK及3M為大宗，您可以選擇適合自己需求的隔熱紙","V-KOOL最頂是V系列但是會擋收訊，可以選擇FSK(F系列)最頂是KT(冰鑽)系列，或是3M最頂是M(極光)系列"]', '業代對話_配備_隔熱紙_推薦'),
	(279, 'D4033', '["安裝汽車隔熱紙可以開來營業所放著，我請廠商來取車！或者我去開回來幫您處理"]', '業代對話_配備_隔熱紙_安裝'),
	(280, 'D4034', '["若隔熱紙太深影響行車視線，那我們可以請廠商幫您拆掉重貼，隔熱紙的型號及費用我再另外跟您報價","隔熱紙太淺有二種解決方式，可以拆掉重貼，或是幫您再加貼一層隔熱紙，隔熱紙的型號及費用我再另外跟您報價","因為每個人對熱度的感知程度不同，若您覺得隔熱仍效果不佳，我們可以幫您拆掉重貼隔熱效果較高階的，或是幫您再加貼一層隔熱紙，隔熱紙的型號及費用我再另外跟您報價"]', '業代對話_配備_隔熱紙_更換'),
	(281, 'D4035', '["汽車隔熱紙大多保固5年，若在保固期限內隔熱紙產生紋路或氣泡可以幫您更換，但若是人為刮損則不在保固範圍"]', '業代對話_配備_隔熱紙_壽命'),
	(282, 'D4036', '["現行車款可以分別訂購駕駛座、前座或全車的腳踏墊，您需要的是哪種組合？我來幫您查一下價格","您的腳踏墊是整組販售，需要的話我來幫您查詢價格"]', '業代對話_車子詢問_腳踏墊_詢價'),
	(283, 'D4037', '["以駕駛座為例價格大概是2","700，一整組最多到7","500，有需要幫您訂料嗎？"]', '業代對話_車子詢問_腳踏墊_給價'),
	(284, 'D4038', '["我們的車很耐開，穩定性也高","每個人對動力的需求不太一樣，現型的車子以環保省油及節能為主，難以全面性滿足各項需求"]', '業代對話_車子詢問_性能詢問_說明'),
	(285, 'D4039', '["我們目前販售三種引擎型式，可以依據您的需求去選購車型，有自然進氣、渦輪及油電引擎，如果需要大馬力可選擇渦輪車型、節能需求可選擇油電車型"]', '業代對話_車子詢問_性能詢問_動力'),
	(286, 'D4040', '["考量到二手車主的接受度及中古車價，挑選基本色黑、白及鈦為大宗色會較好脫手"]', '業代對話_車子詢問_顏色脫手_建議'),
	(287, 'D4041', '["CPO(原廠認證中古車)的舊車回收範圍為車齡五年內及里程數10萬公里內，若不符回收資格只能幫您委外其他管道處理"]', '業代對話_車子詢問_舊車查估_資格'),
	(288, 'D4042', '["請您把行照及里程數拍給我，我請CPO(原廠認證中古車)來幫您預估車價行情，但實際車價還是要約個時間讓我們幫您做實車查估","抱歉，公司CPO(原廠認證中古車)沒有收事故汽車，只能幫您委外其他管道處理","那我再幫您跟CPO(原廠認證中古車)協商中古車價，盡快回覆您消息"]', '業代對話_車子詢問_舊車查估_價格'),
	(289, 'D4043', '["若CPO(原廠認證中古車)確認回收您的舊收，您需準備雙證件正本、車主印鑑及行照跟牌登書正本，而過戶手續他們會幫您完成"]', '業代對話_車子詢問_舊車查估_過戶'),
	(290, 'D4044', '["舊車的收購價可以移轉成新車的尾款，或是提供存摺封面影本/銀行帳戶直接電匯收購價給您","提供存摺封面影本/銀行帳戶直接電匯舊車收購價給您"]', '業代對話_車子詢問_舊車查估_金流'),
	(291, 'D4045', '["若您的舊車要報廢，提醒您在報廢前後半年內購買新車完成領牌者，會有政府貨物稅減徵的5萬元補助","舊車報廢需準備舊車牌登書影本、身份證正反面影本及車主印鑑，我會請回收廠商到府取車，為您完成報廢流程"]', '業代對話_車子詢問_報廢_說明'),
	(292, 'D4046', '["申請政府貨物稅減徵5萬元補助需符合的條件：舊車持有1年以上，新舊車主需為二等親內(可以不同戶籍)，及舊車報廢前後半年內購置新車完成領牌者","依舊車報廢前後半年內購置新車完成領牌者，可申請政府貨物稅減徵的5萬元補助"]', '業代對話_車子詢問_報廢_資格'),
	(293, 'D4047', '["完成新車領牌及舊車報廢，由我協助幫您申請貨物稅減徵，而5萬元的補助大約於申請後三個月匯款於您的帳戶"]', '業代對話_車子詢問_報廢_減徵'),
	(294, 'D4048', '["乙式與丙式的差異是在事故認定標準，丙式僅車碰車才能受理理賠，而乙式的理賠範圍增加自撞、翻車、火災、閃電(雷擊)、爆炸、拋擲物及墜落物等，所以乙式相較符合日常生活中，較常會遇到的意外風險的理賠範圍"]', '業代對話_車子詢問_保險_差異'),
	(295, 'D4049', '["您目前看到的保險報價已幫您爭取保險公司的優惠了，透過LEXUS承保的理賠程序簡單又快速，且服務較完善，是沒辦法跟自行投保去比較的"]', '業代對話_車子詢問_保險_折扣'),
	(296, 'D4050', '["車門側邊(六角鎖)的塑膠孔蓋是維修孔","車門內飾板上的圓孔是進風口，是儀錶板出風孔連接冷氣到門飾板的出風口"]', '業代對話_學車功能_車門_圓孔'),
	(297, 'D4051', '["按下搖控器上鎖鍵或車門外把手會啟動防盜系統，且開啟侵入感知系統開關，系統會自動偵測車內，當異常入侵時會使用燈光和聲響來發出警報 "]', '業代對話_學車功能_車門_侵入感知器'),
	(298, 'D4052', '["當後視鏡選擇調整開關在「L」或「R」位置，在車輛打R檔倒車時會自動下傾調整","當後視鏡調整開關沒有選擇「L」或「R」位置，即關閉R檔自動下傾調整功能"]', '業代對話_學車功能_後視鏡_向下'),
	(299, 'D4053', '["依車型的配備為主，所以只能下車時麻煩您手動收折後視鏡","在駕駛座門邊的後視鏡自動收折(AUTO)按鈕，後視鏡會自動折疊進來"]', '業代對話_學車功能_後視鏡_收折'),
	(300, 'D4054', '["換檔撥片左是降檔 右是升檔，可以不用去操作排檔桿就可以達到升降檔的作用"]', '業代對話_學車功能_換檔撥片_介紹'),
	(301, 'D4055', '["M檔類似手排檔功能，需要自行選擇檔數才會換檔，但引擎防護機制啟動時，仍會自動切換檔數，確保行車安全 ","M檔適用在低速檔爬坡高扭力、長下坡或滑行低速檔做檔煞降速、急加速增加駕馭樂趣"]', '業代對話_學車功能_換檔撥片_M檔'),
	(302, 'D4056', '["D檔類似手自排功能，可以使用撥片換檔，它會依車速及行駛狀況自動選擇檔數 ","D檔適用在一般平面、快速及高速公路上 "]', '業代對話_學車功能_換檔撥片_D檔'),
	(303, 'D4057', '["定速有分成二種，一種是DRCC雷達感應式車距維持定速系統，另一種是一般定速 ","DRCC有自動跟車功能，一般定速系統是不會隨著前車速度做變化 "]', '業代對話_學車功能_巡航定速_說明'),
	(304, 'D4058', '["在兩車間距控制模式中，駕駛人不需踩油門踏板，車輛會依據當時駕駛所設定的車速，與前車車速變化自動加減速 ","使用定速系統可在不踩油門踏板的情況下維持當時駕駛所設定的車速(不含DRCC車距調整)"]', '業代對話_學車功能_巡航定速_介紹'),
	(305, 'D4059', '["操作定速撥桿，按下主開關直到定速燈亮起，然後將控制桿向下扳(往SET方向撥)，即完成車主想要設定的車速","開啟「定速系統主開關」直到定速燈亮起，然後按下「-SET」開關，即完成車主想要設定的車速","「定速系統主開關」在方向盤右側「CANCEL」鍵的右上方(有一台車和儀表板的圖示)"]', '業代對話_學車功能_巡航定速_設定'),
	(306, 'D4060', '["定速系統會於下列任一狀況自動取消(1)實際車速下降超過設定約16km以上、(2)實際車速低於40km/h、(3)VSC/TRC作動或(4)VCS OFF開關關閉VSC或TRC系統，皆會自動取消定速系統 ","結束(取消)定速有二種方法，可以踩煞車暫時取消、關掉定速功能需關閉定速開關"]', '業代對話_學車功能_巡航定速_關閉'),
	(307, 'D4061', '["在多功能資訊顯示幕上，顯示「定速巡航故障 請至經銷商檢查」"]', '業代對話_學車功能_巡航定速_異常'),
	(308, 'D4062', '["若發現定速系統無法啟動，先關閉系統，再按一下按鈕重新啟動系統，如果仍無法設定定速系統或定速系統啟動後馬上停止，請回廠檢查"]', '業代對話_學車功能_巡航定速_處理'),
	(309, 'D4063', '["自動除霧功能開啟後擋除霧器時，車外後視鏡除霧器也會同時除霧","開啟自動除霧功能可於(1)EMV(Remote Touch螢幕)上的擋風玻璃除霧器開關、(2)控制面板上面開啟前/後除霧按鈕 "]', '業代對話_學車功能_自動除霧_說明'),
	(310, 'D4064', '["在方向盤左手方，有一個「ODO TRIP」的按鈕，可顯示里程表及計程表 "]', '業代對話_學車功能_儀表板_顯示公里數'),
	(311, 'D4065', '["油耗分為平均油耗和瞬間油耗，一般會顯示的是每一公升跑幾公里，也有的會顯示每一公里耗費的公升數","油耗計算方式是每公升跑幾公里，並於每15分鐘計算一次"]', '業代對話_學車功能_油耗_說明'),
	(312, 'D4066', '["查詢油耗可開啟EMV(Remote Touch資訊整合操作介面)前方的「MENU」按鈕，將會顯示相關油耗資訊","查詢油耗可於儀表板的綜合顯示幕，開啟行駛資訊( i 圖示)開關，即可得到相關油耗資訊"]', '業代對話_學車功能_油耗_開啟'),
	(313, 'D4067', '["行駛資訊1會顯示(1)目前的耗油量及(2)重設後的平均油耗","行駛資訊2會顯示(1)續航里程的距離及(2)重設後的平均車速","行駛資訊3會顯示(1)加油後的平均油耗及(2)啟動後的經過時間"]', '業代對話_學車功能_行駛資訊_說明'),
	(314, 'D4068', '["顯示目前的瞬間油耗"]', '業代對話_學車功能_瞬間油耗_耗量'),
	(315, 'D4069', '["行駛資訊視窗會有顯示重設後的平均油耗(每15分鐘會重新計算)"]', '業代對話_學車功能_平均油耗_重設'),
	(316, 'D4070', '["行駛資訊視窗會有顯示自引擎啟動後的平均油耗"]', '業代對話_學車功能_平均油耗_啟動'),
	(317, 'D4071', '["行駛資訊視窗會有顯示自加油後的平均油耗"]', '業代對話_學車功能_平均油耗_加油'),
	(318, 'D4072', '["行駛資訊視窗會有自重設後的平均車速(每15分鐘會自動重新計算)"]', '業代對話_學車功能_平均車速_重設'),
	(319, 'D4073', '["行駛資訊視窗會有顯示引擎啟動後的平均車速"]', '業代對話_學車功能_平均車速_啟動'),
	(320, 'D4074', '["行駛資訊視窗會有自重設後的經過時間(每15分鐘會自動重新計算)"]', '業代對話_學車功能_行駛時間_重設'),
	(321, 'D4075', '["行駛資訊視窗會有顯示引擎啟動後的經過時間"]', '業代對話_學車功能_行駛時間_啟動'),
	(322, 'D4076', '["行駛資訊視窗會有顯示剩餘燃油的續航里程"]', '業代對話_學車功能_距離_行駛'),
	(323, 'D4077', '["行駛資訊視窗會有顯示車輛起步後的行駛距離"]', '業代對話_學車功能_距離_啟動'),
	(324, 'D4078', '["提供正廠第三代影音操作影片給您參考 https://youtu.be/NJ5sUQ96Ivk"]', '業代對話_學車功能_影音系統_教學'),
	(325, 'D4079', '["正廠用品是由汽車代理商開發，或指定的車輛用品公司所生產的配件"]', '業代對話_學車功能_影音系統_說明'),
	(326, 'D4080', '["電視觀看限制有受限於政府法令規範，所以車廠會設定成車輛行進間切掉畫面","導航設定基於行車安全，在車輛行進間有些功能是無法操作"]', '業代對話_學車功能_影音系統_限制'),
	(327, 'D4081', '["手機打開WiFi，車機就找得到手機的連結"]', '業代對話_學車功能_Miracast_安卓'),
	(328, 'D4082', '["Apple手機要接HDMI(插孔在副駕駛座的手套箱附近)"]', '業代對話_學車功能_Miracast_蘋果'),
	(329, 'D4083', '["如果你手機是iOS系統，要先擁有Apple的Lightning Digital AV 轉接器，及HDMI線就能使用Miracast(手機畫面同步到車上螢幕的功能)"]', '業代對話_學車功能_Miracast_轉接'),
	(330, 'D4084', '["可以打開油箱蓋，內側有標註建議的油品","依照您的車型建議加92以上的油","依照您的車型建議加95以上的油"]', '業代對話_汽車知識_汽油_加油'),
	(331, 'D4085', '["建議參考使用手冊，使用固定油品，更換油品針對引擎效能沒有顯著影響(目前市售的油品無鉛汽油92、95及98)","因為更換油品針對引擎效能沒有顯著影響，所以可以直接更換油品"]', '業代對話_汽車知識_汽油_更換'),
	(332, 'D4086', '["油箱總容量是___L，油加滿約略___L(油針指在最後底線上，加滿大約___L)","預備油量是___L，如果亮燈的話，還是建議您趕快去加油"]', '業代對話_汽車知識_汽油_容量'),
	(333, 'D4087', '["清除汽車引擎的汽門、噴油嘴、汽缸燃燒等積碳的功用","配合服務廠定期保養週期時添加","請勿放在車廂避免高溫40度以上，會產生危險"]', '業代對話_汽車知識_汽油精_說明'),
	(334, 'D4088', '["參照使用手冊定期保養週期更換機油","公司建議第一次回廠不用換機油，因滿月檢查里程數累計不高，不需要額外更換機油，不會讓您多消費"]', '業代對話_汽車知識_機油_回廠'),
	(335, 'D4089', '["機油需要___公升，您那個一瓶946ml，要帶___瓶才夠用","機油需要___公升，您那個一瓶1000ml，要帶___瓶才夠用"]', '業代對話_汽車知識_機油_自備'),
	(336, 'D4090', '["於2年4萬、4年8萬的定期保養時會檢查，再視時需要進行更換 ","4萬，8萬公里檢查，視情況才會更換(大部份是8萬建議換)","正時皮帶是屬於引擎的內部皮帶，帶動周邊機構產生動能"]', '業代對話_汽車知識_正時皮帶_說明'),
	(337, 'D4091', '["正時皮帶是7.5年或15萬公里首次更換"]', '業代對話_汽車知識_正時皮帶_壽命'),
	(338, 'D4092', '["正時皮帶一旦斷裂，此時極有可能導致汽門與活塞撞擊，引擎汽門彎曲損毀導致車子拋錨無法行駛，建議定期更換"]', '業代對話_汽車知識_正時皮帶_影響'),
	(339, 'D4093', '["正時皮帶更換時間約4個小時，不包含保養作業時間     "]', '業代對話_汽車知識_正時皮帶_工時'),
	(340, 'D4094', '["車上有各種的電磁閥，需要回廠檢查，才能幫您確認是哪個問題"]', '業代對話_緊急處理_電磁閥_說明'),
	(341, 'D4095', '["您是車子沒有電能自行接電，還是需要我們過去幫您接電救援呢？"]', '業代對話_緊急處理_輔助電瓶_求救'),
	(342, 'D4096', '["接電啟動順序(1)先將紅色線連接救援車的電瓶正極(＋)端，(2)再把紅色線的另一端夾到外接電瓶的正極(＋)端；(3)把黑色線連接在外接電瓶負極(－)端，(4)黑色線的另一端連接到救援車(沒有塗裝、噴漆或不會轉動的金屬板)即可接電啟動","接不了電可以撥打0800-091-091與LEXUS道路救援聯繫"]', '業代對話_緊急處理_輔助電瓶_接電'),
	(343, 'D4097', '["接電啟動後可以行駛的話，就這樣不要熄火開去LEXUS服務廠"]', '業代對話_緊急處理_接電處理_可駛'),
	(344, 'D4098', '["接電啟動後如果中途還熄火，需立即將車輛停到安全地點，並撥打0800-091-091與LEXUS道路救援聯繫"]', '業代對話_緊急處理_接電處理_熄火'),
	(345, 'D4099', '["需立即將車輛停到安全地點，並撥打0800-091-091與LEXUS道路救援聯繫"]', '業代對話_緊急處理_接電處理_無法'),
	(346, 'D4100', '["是什麼樣的聲音？是在什麼情況下發生的？聲音頻繁嗎？","您再安排時間回廠，我會請技師幫您檢查","如果按鈕無法作動，需回廠幫您拆檢確認問題","警示燈亮起需回廠使用檢診電腦，幫您檢測是哪方面的問題"]', '業代對話_緊急處理_警示燈_處理'),
	(347, 'D4101', '["建議安排回廠檢查喔"]', '業代對話_緊急處理_不明原因_回廠'),
	(348, 'D5101', '["妳好"]', '日常用語_短語:打招呼'),
	(349, 'D5102', '["早上好~"]', '日常用語_短語:早安'),
	(350, 'D5103', '["午安呀~"]', '日常用語_短語:午安'),
	(351, 'D5104', '["下午好"]', '日常用語_短語:下午好'),
	(352, 'D5105', '["晚上好~"]', '日常用語_短語:晚安'),
	(353, 'D5002', '["Googbye"]', '日常用語_短語:再見'),
	(354, 'D5003', '["抒發情緒有很多管道，LEXUS不定期舉辦活動，用歡樂活動趕走滿滿的負能量吧~"]', '日常用語_短語:謾罵'),
	(355, 'D5004', '["謝謝"]', '日常用語_短語:正面評論'),
	(356, 'D5005', '["謝謝您的指教，若有其他建議可以於客服信箱留言，我們將盡快為你處理"]', '日常用語_短語:負面評論'),
	(357, 'D5006', '["去吧~追隨LEXUS的車尾燈，狂奔爆汗，喚醒身體和腦袋，幫你趕走滿滿的厭世"]', '日常用語_短語:厭世'),
	(358, 'D5007', '["不管天氣好不好 保持一顆愉悅的心 LEXUS祝福您每天都順心~"]', '日常用語_關鍵字短語:天氣'),
	(359, 'D5015', '["在失智病房內，醫生:忘記了姓名的請跟我來，病人:現在讓我們向快樂崇拜"]', '日常用語_關鍵字短語:笑話'),
	(360, 'D6001', '["有什麼需要我幫忙的？"]', '簡易客服_尋求服務目錄'),
	(361, 'D6006', '["線上預約您想試乘的車款親身體驗LEXUS的尊榮旅程"]', '簡易客服_預約試乘'),
	(362, 'D6007', '["歡迎前往 LEXUS 展示中心，由專人為您介紹車款資訊"]', '簡易客服_購車需求'),
	(363, 'D6008', '["請問是什麼東西需要維修保養呢~"]', '簡易客服_維修保養'),
	(364, 'D6010', '["豪華跨界休旅 UX 新車上市！https://www.lexus.com.tw/event/201811_UX/"]', '簡易客服_新車推薦'),
	(365, 'D6011', '["LEXUS全車系分期零利率購車優惠，是您入主LEXUS的最佳時機，讓您輕鬆享受完美座駕的尊榮旅程"]', '簡易客服_最新優惠'),
	(366, 'NORMAL_BIRTH', '["祝您生日快樂!事事順心~準備小禮物要送給您","祝您許的願望都能實現，生日快樂！","祝您許的願望都能實現，生日快樂！","祝您許的願望都能實現，生日快樂！","祝您許的願望都能實現，生日快樂！","祝您許的願望都能實現，生日快樂！","祝您許的願望都能實現，生日快樂！","祝您許的願望都能實現，生日快樂！","祝您許的願望都能實現，生日快樂！","祝您許的願望都能實現，生日快樂！"]', '一般話術-生日'),
	(367, 'NORMAL_FEN', '["保險即將到期，麻煩您安排時間完成續保事宜","提醒您愛車保險要到期囉，去年保單給您參考！","提醒您愛車保險要到期囉，去年保單給您參考！","提醒您愛車保險要到期囉，去年保單給您參考！","提醒您愛車保險要到期囉，去年保單給您參考！","提醒您愛車保險要到期囉，去年保單給您參考！","提醒您愛車保險要到期囉，去年保單給您參考！","提醒您愛車保險要到期囉，去年保單給您參考！","提醒您愛車保險要到期囉，去年保單給您參考！","提醒您愛車保險要到期囉，去年保單給您參考！"]', '一般話術-續保'),
	(368, 'NORMAL_HOTAI', '["Hi 您的愛車保養週期到了，需要幫您預約？","提醒您明天要入廠保養車喔 ","提醒您明天要入廠保養車喔 ","提醒您明天要入廠保養車喔 ","提醒您明天要入廠保養車喔 ","提醒您明天要入廠保養車喔 ","提醒您明天要入廠保養車喔 ","提醒您明天要入廠保養車喔 ","提醒您明天要入廠保養車喔 ","提醒您明天要入廠保養車喔 "]', '一般話術-推播'),
	(369, 'NORMAL_OTHER', '["順便幫我帶您的木頭印章來取車","麻煩準備公司大小章，蓋出險用的還有您的印章","麻煩準備公司大小章，蓋出險用的還有您的印章","麻煩準備公司大小章，蓋出險用的還有您的印章","麻煩準備公司大小章，蓋出險用的還有您的印章","麻煩準備公司大小章，蓋出險用的還有您的印章","麻煩準備公司大小章，蓋出險用的還有您的印章","麻煩準備公司大小章，蓋出險用的還有您的印章","麻煩準備公司大小章，蓋出險用的還有您的印章","麻煩準備公司大小章，蓋出險用的還有您的印章"]', '一般話術-其他');
/*!40000 ALTER TABLE `tb_talk_tricks_default` ENABLE KEYS */;

-- 傾印  表格 db_lexus_cs.tb_uploaded_picture 結構
CREATE TABLE IF NOT EXISTS `tb_uploaded_picture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` char(40) DEFAULT NULL,
  `picture_name` varchar(100) DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `upload_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- 正在傾印表格  db_lexus_cs.tb_uploaded_picture 的資料：~0 rows (大約)
/*!40000 ALTER TABLE `tb_uploaded_picture` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_uploaded_picture` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
