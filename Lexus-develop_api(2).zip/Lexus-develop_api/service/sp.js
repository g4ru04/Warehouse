const settings = require('../configs.js');
const request = require('request-promise');
var FroalaEditor = require('wysiwyg-editor-node-sdk/lib/froalaEditor.js');
 module.exports = {
	upload_image: function(req, res){
		// Store image.
		FroalaEditor.Image.upload(req, '../public/images/uploaded/', function(err, data) {
			// Return data.
			if (err) {
				console.log("err", err);
				return res.send(JSON.stringify(err));
			}
			console.log("data", data);
			res.send(data);
		});
	}
} 